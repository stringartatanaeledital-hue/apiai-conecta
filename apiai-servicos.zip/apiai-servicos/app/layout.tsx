import type { Metadata, Viewport } from "next";
import { SessionProvider } from "@/lib/SessionContext";
import { ConvexClientProvider } from "@/lib/ConvexClientProvider";
import "./globals.css";

export const metadata: Metadata = {
  title: "Apiaí Serviços",
  description:
    "Encontre pintores, mecânicos, jardineiros, marcenarias e todo tipo de profissional em Apiaí e região.",
  manifest: "/manifest.json",
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/icon-192.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#f5a623",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="bg-black text-white antialiased">
        <ConvexClientProvider>
          <SessionProvider>{children}</SessionProvider>
        </ConvexClientProvider>
      </body>
    </html>
  );
}

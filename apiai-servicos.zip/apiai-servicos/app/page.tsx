"use client";

// ============================================================================
// app/page.tsx — Apiaí Serviços
// Página principal: mostra Login/Cadastro se não houver sessão, e o
// AppShell completo (com todos os módulos) se o usuário já estiver logado.
// ============================================================================

import { useState } from "react";
import { useSession } from "@/lib/SessionContext";
import Login from "@/components/Login";
import CadastroUsuario from "@/components/CadastroUsuario";
import AppShell, { NavKey } from "@/components/AppShell";
import ClienteHome from "@/components/ClienteHome";
import SolicitarServico from "@/components/SolicitarServico";
import Marketplace from "@/components/Marketplace";
import Agenda from "@/components/Agenda";
import Financeiro from "@/components/Financeiro";
import Cursos from "@/components/Cursos";
import CentralEmergencia from "@/components/CentralEmergencia";
import MapaInteligente from "@/components/MapaInteligente";
import PainelAdmin from "@/components/PainelAdmin";
import PainelCategorias from "@/components/PainelCategorias";
import PainelClientes from "@/components/PainelClientes";
import PainelConvidados from "@/components/PainelConvidados";
import BuscarProfissionais from "@/components/BuscarProfissionais";
import ListaConversas from "@/components/ListaConversas";
import ChatJanela from "@/components/ChatJanela";
import Fidelidade from "@/components/Fidelidade";
import { RankingProfissionais } from "@/components/Gamificacao";
import Configuracoes from "@/components/Configuracoes";
import ResultadosBusca from "@/components/ResultadosBusca";
import { Id } from "@/convex/_generated/dataModel";

export default function HomePage() {
  const { user, isLoading } = useSession();
  const [showCadastro, setShowCadastro] = useState(false);
  const [activeKey, setActiveKey] = useState<NavKey>("dashboard");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeConversationId, setActiveConversationId] = useState<Id<"conversations"> | null>(
    null
  );

  if (isLoading) {
    return <div className="min-h-screen bg-black" />;
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center gap-4 p-6">
        <h1 className="text-2xl font-bold text-amber-400 mb-2">Apiaí Serviços</h1>
        {showCadastro ? (
          <CadastroUsuario onRegistered={() => setShowCadastro(false)} />
        ) : (
          <Login />
        )}
        <button
          onClick={() => setShowCadastro((v) => !v)}
          className="text-zinc-400 text-sm underline"
        >
          {showCadastro ? "Já tenho conta — entrar" : "Não tenho conta — cadastrar"}
        </button>
      </div>
    );
  }

  const userId = user.userId as unknown as Id<"users">;
  const isAdmin = user.role === "admin";

  return (
    <AppShell
      activeKey={activeKey}
      onNavigate={setActiveKey}
      userName={user.name}
      userRole={user.role}
    >
      {searchQuery && <ResultadosBusca query={searchQuery} />}
      {!searchQuery && activeKey === "dashboard" && (
        <ClienteHome onSelectProfissao={() => setActiveKey("orcamentos")} />
      )}
      {!searchQuery && activeKey === "orcamentos" && <SolicitarServico clientId={userId} />}
      {!searchQuery && (activeKey === "profissionais" || activeKey === "seguranca") && (
        <BuscarProfissionais
          initialCategory={activeKey === "seguranca" ? "seguranca_trabalho" : undefined}
        />
      )}
      {!searchQuery && activeKey === "marketplace" && <Marketplace buyerId={userId} />}
      {!searchQuery && activeKey === "agenda" && <Agenda ownerId={userId} />}
      {!searchQuery && activeKey === "financeiro" && <Financeiro ownerId={userId} />}
      {!searchQuery && activeKey === "cursos" && <Cursos userId={userId} />}
      {!searchQuery && activeKey === "emergencia" && <CentralEmergencia />}
      {!searchQuery && activeKey === "mapa" && <MapaInteligente />}
      {!searchQuery && activeKey === "gamificacao" && <RankingProfissionais />}
      {!searchQuery && activeKey === "fidelidade" && <Fidelidade userId={userId} />}
      {!searchQuery && activeKey === "configuracoes" && <Configuracoes userId={userId} />}

      {!searchQuery && activeKey === "mensagens" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[70vh]">
          <div className="md:col-span-1">
            <ListaConversas userId={userId} onSelect={setActiveConversationId} />
          </div>
          <div className="md:col-span-2">
            {activeConversationId ? (
              <ChatJanela conversationId={activeConversationId} currentUserId={userId} />
            ) : (
              <div className="h-full flex items-center justify-center rounded-xl border border-zinc-800 bg-zinc-900/60 text-zinc-500 text-sm">
                Selecione uma conversa
              </div>
            )}
          </div>
        </div>
      )}

      {/* Módulos administrativos — visíveis apenas para quem tem role "admin" */}
      {!searchQuery && activeKey === "admin" && isAdmin && <PainelAdmin />}
      {!searchQuery && activeKey === "admin" && !isAdmin && (
        <p className="text-zinc-500 text-sm">Acesso restrito ao administrador.</p>
      )}
      {!searchQuery && activeKey === "categorias" && isAdmin && (
        <PainelCategorias adminUserId={userId} />
      )}
      {!searchQuery && activeKey === "clientes" && isAdmin && <PainelClientes />}
      {!searchQuery && activeKey === "clientes" && !isAdmin && (
        <p className="text-zinc-500 text-sm">Acesso restrito ao administrador.</p>
      )}
    </AppShell>
  );
}

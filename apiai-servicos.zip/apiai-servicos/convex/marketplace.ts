// ============================================================================
// convex/marketplace.ts
// Backend do Marketplace por Departamentos — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const departmentValidator = v.union(
  v.literal("ferramentas"),
  v.literal("epis"),
  v.literal("materiais"),
  v.literal("maquinas"),
  v.literal("aluguel"),
  v.literal("pecas"),
  v.literal("equipamentos")
);

export const DEPARTMENT_LABELS: Record<string, string> = {
  ferramentas: "Ferramentas",
  epis: "EPIs",
  materiais: "Materiais",
  maquinas: "Máquinas",
  aluguel: "Aluguel",
  pecas: "Peças",
  equipamentos: "Equipamentos",
};

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => await ctx.storage.generateUploadUrl(),
});

export const createProduct = mutation({
  args: {
    sellerId: v.id("users"),
    department: departmentValidator,
    relatedProfession: v.optional(v.string()),
    name: v.string(),
    description: v.optional(v.string()),
    priceCents: v.number(),
    isRental: v.boolean(),
    rentalPricePerDayCents: v.optional(v.number()),
    stock: v.number(),
    imageStorageIds: v.array(v.id("_storage")),
    isPromo: v.boolean(),
    promoDiscountPercent: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("marketplaceProducts", { ...args, createdAt: Date.now() });
  },
});

// Produtos recomendados para uma profissão específica (ex: "Pintor" →
// rolos, tintas, fitas crepe; "Jardineiro" → roçadeiras, adubo, tesouras)
export const listByProfession = query({
  args: { relatedProfession: v.string() },
  handler: async (ctx, { relatedProfession }) => {
    const products = await ctx.db
      .query("marketplaceProducts")
      .withIndex("by_relatedProfession", (q) => q.eq("relatedProfession", relatedProfession))
      .collect();

    return await Promise.all(
      products.map(async (p) => ({
        ...p,
        imageUrls: await Promise.all(p.imageStorageIds.map((id) => ctx.storage.getUrl(id))),
      }))
    );
  },
});

// Lista produtos de um departamento, mais recentes primeiro
export const listByDepartment = query({
  args: { department: departmentValidator },
  handler: async (ctx, { department }) => {
    const products = await ctx.db
      .query("marketplaceProducts")
      .withIndex("by_department", (q) => q.eq("department", department))
      .order("desc")
      .collect();

    return await Promise.all(
      products.map(async (p) => ({
        ...p,
        imageUrls: await Promise.all(p.imageStorageIds.map((id) => ctx.storage.getUrl(id))),
      }))
    );
  },
});

// Contagem por departamento, para os cards de navegação
export const countByDepartment = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("marketplaceProducts").collect();
    const counts: Record<string, number> = {};
    for (const p of all) counts[p.department] = (counts[p.department] ?? 0) + 1;
    return counts;
  },
});

export const listPromotions = query({
  args: {},
  handler: async (ctx) => {
    const promos = await ctx.db
      .query("marketplaceProducts")
      .withIndex("by_promo", (q) => q.eq("isPromo", true))
      .order("desc")
      .collect();

    return await Promise.all(
      promos.map(async (p) => ({
        ...p,
        imageUrls: await Promise.all(p.imageStorageIds.map((id) => ctx.storage.getUrl(id))),
      }))
    );
  },
});

export const createOrder = mutation({
  args: {
    productId: v.id("marketplaceProducts"),
    buyerId: v.id("users"),
    quantity: v.number(),
  },
  handler: async (ctx, { productId, buyerId, quantity }) => {
    const product = await ctx.db.get(productId);
    if (!product) throw new Error("Produto não encontrado");
    if (product.stock < quantity) throw new Error("Estoque insuficiente");

    const unitPrice = product.isPromo
      ? Math.round(product.priceCents * (1 - (product.promoDiscountPercent ?? 0) / 100))
      : product.priceCents;

    await ctx.db.patch(productId, { stock: product.stock - quantity });

    return await ctx.db.insert("marketplaceOrders", {
      productId,
      buyerId,
      quantity,
      totalCents: unitPrice * quantity,
      status: "pendente",
      createdAt: Date.now(),
    });
  },
});

export const listMyOrders = query({
  args: { buyerId: v.id("users") },
  handler: async (ctx, { buyerId }) => {
    return await ctx.db
      .query("marketplaceOrders")
      .withIndex("by_buyer", (q) => q.eq("buyerId", buyerId))
      .order("desc")
      .collect();
  },
});

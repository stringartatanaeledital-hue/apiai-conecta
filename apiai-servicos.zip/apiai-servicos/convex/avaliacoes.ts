// ============================================================================
// convex/avaliacoes.ts — Avaliações pós-serviço — Apiaí Serviços
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const addReview = mutation({
  args: {
    orderId: v.id("serviceOrders"),
    clientId: v.id("users"),
    professionalId: v.id("users"),
    rating: v.number(),
    comment: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("reviews")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .unique();
    if (existing) throw new Error("Este serviço já foi avaliado");

    return await ctx.db.insert("reviews", { ...args, createdAt: Date.now() });
  },
});

export const listByProfessional = query({
  args: { professionalId: v.id("users") },
  handler: async (ctx, { professionalId }) => {
    const reviews = await ctx.db
      .query("reviews")
      .withIndex("by_professional", (q) => q.eq("professionalId", professionalId))
      .order("desc")
      .collect();

    return await Promise.all(
      reviews.map(async (r) => {
        const client = await ctx.db.get(r.clientId);
        return { ...r, clientName: (client as any)?.name ?? "Cliente" };
      })
    );
  },
});

export const getAverageRating = query({
  args: { professionalId: v.id("users") },
  handler: async (ctx, { professionalId }) => {
    const reviews = await ctx.db
      .query("reviews")
      .withIndex("by_professional", (q) => q.eq("professionalId", professionalId))
      .collect();

    if (reviews.length === 0) return { average: null, count: 0 };
    const average = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
    return { average: Math.round(average * 10) / 10, count: reviews.length };
  },
});

export const getReviewForOrder = query({
  args: { orderId: v.id("serviceOrders") },
  handler: async (ctx, { orderId }) => {
    return await ctx.db
      .query("reviews")
      .withIndex("by_order", (q) => q.eq("orderId", orderId))
      .unique();
  },
});

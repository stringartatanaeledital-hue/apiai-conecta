// ============================================================================
// convex/emergencia.ts — Central de Emergência 24h — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const categoryValidator = v.union(
  v.literal("chaveiro"),
  v.literal("guincho"),
  v.literal("eletricista"),
  v.literal("encanador")
);

export const registerProvider = mutation({
  args: {
    category: categoryValidator,
    name: v.string(),
    phone: v.string(),
    latitude: v.number(),
    longitude: v.number(),
    isAvailable24h: v.boolean(),
    rating: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("emergencyProviders", { ...args, createdAt: Date.now() });
  },
});

export const listByCategory = query({
  args: { category: categoryValidator },
  handler: async (ctx, { category }) => {
    return await ctx.db
      .query("emergencyProviders")
      .withIndex("by_category", (q) => q.eq("category", category))
      .collect();
  },
});

export const listAll24h = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("emergencyProviders").collect();
    return all.filter((p) => p.isAvailable24h);
  },
});

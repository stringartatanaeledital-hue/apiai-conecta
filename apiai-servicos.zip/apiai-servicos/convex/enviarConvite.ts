// ============================================================================
// convex/enviarConvite.ts — Apiaí Serviços
// Quando VOCÊ (dono/admin) manda um convite pra alguém específico — por
// exemplo, um amigo — você já decide na hora se essa pessoa vai usar de
// graça ou vai pagar normalmente. Não depende de aprovação depois.
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const enviarConviteDireto = mutation({
  args: {
    userId: v.id("users"), // pra quem o convite é enviado
    modoAcesso: v.union(v.literal("gratuito"), v.literal("pago")),
    benefitDescription: v.optional(v.string()),
    sentBy: v.optional(v.id("users")),
  },
  handler: async (ctx, { userId, modoAcesso, benefitDescription, sentBy }) => {
    if (modoAcesso === "gratuito") {
      const existing = await ctx.db
        .query("guestAccessGrants")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .collect();

      if (!existing.some((g) => g.isActive)) {
        await ctx.db.insert("guestAccessGrants", {
          userId,
          grantedBy: sentBy,
          benefitDescription: benefitDescription ?? "Acesso gratuito concedido pelo administrador",
          isActive: true,
          createdAt: Date.now(),
        });
      }
      return { modoAcesso: "gratuito" as const };
    }

    // modo "pago": não cria nenhum registro de gratuidade — a pessoa segue
    // o cadastro e cobrança normal da plataforma.
    return { modoAcesso: "pago" as const };
  },
});

// Lista simples de usuários pra você escolher na hora de enviar o convite
export const listUsersForInvite = query({
  args: { searchText: v.optional(v.string()) },
  handler: async (ctx, { searchText }) => {
    let users = await ctx.db.query("users").collect();
    if (searchText) {
      const term = searchText.toLowerCase();
      users = users.filter(
        (u) => u.name.toLowerCase().includes(term) || u.email.toLowerCase().includes(term)
      );
    }
    return users.slice(0, 20);
  },
});

// ============================================================================
// convex/serviceTimeline.ts
// Backend da Linha do Tempo do Serviço — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const STATUS_VALUES = [
  "solicitado",
  "orcamento",
  "aceito",
  "em_execucao",
  "concluido",
  "avaliacao",
] as const;

const statusValidator = v.union(
  v.literal("solicitado"),
  v.literal("orcamento"),
  v.literal("aceito"),
  v.literal("em_execucao"),
  v.literal("concluido"),
  v.literal("avaliacao")
);

// Rótulos amigáveis usados no frontend (mantidos aqui para reuso no backend
// em notificações, por exemplo).
export const STATUS_LABELS: Record<(typeof STATUS_VALUES)[number], string> = {
  solicitado: "Solicitado",
  orcamento: "Orçamento",
  aceito: "Aceito",
  em_execucao: "Em execução",
  concluido: "Concluído",
  avaliacao: "Avaliação",
};

// ----------------------------------------------------------------------
// QUERY: retorna todos os eventos de uma ordem, em ordem cronológica
// ----------------------------------------------------------------------
export const getTimelineByOrder = query({
  args: { orderId: v.id("serviceOrders") },
  handler: async (ctx, { orderId }) => {
    const events = await ctx.db
      .query("serviceTimelineEvents")
      .withIndex("by_order", (q) => q.eq("orderId", orderId))
      .order("asc")
      .collect();

    const statusRow = await ctx.db
      .query("serviceOrderStatus")
      .withIndex("by_order", (q) => q.eq("orderId", orderId))
      .unique();

    return {
      events,
      currentStatus: statusRow?.currentStatus ?? null,
      updatedAt: statusRow?.updatedAt ?? null,
    };
  },
});

// ----------------------------------------------------------------------
// MUTATION: adiciona um novo evento e atualiza o status "cache" da ordem
// Use isso sempre que o status de uma ordem mudar (cliente aceitou
// orçamento, profissional iniciou execução, etc.)
// ----------------------------------------------------------------------
export const addTimelineEvent = mutation({
  args: {
    orderId: v.id("serviceOrders"),
    status: statusValidator,
    title: v.string(),
    description: v.optional(v.string()),
    actorId: v.optional(v.id("users")),
    actorName: v.optional(v.string()),
    actorRole: v.optional(
      v.union(v.literal("cliente"), v.literal("profissional"), v.literal("sistema"))
    ),
    metadata: v.optional(v.any()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const eventId = await ctx.db.insert("serviceTimelineEvents", {
      orderId: args.orderId,
      status: args.status,
      title: args.title,
      description: args.description,
      actorId: args.actorId,
      actorName: args.actorName,
      actorRole: args.actorRole,
      metadata: args.metadata,
      createdAt: now,
    });

    const existingStatus = await ctx.db
      .query("serviceOrderStatus")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .unique();

    if (existingStatus) {
      await ctx.db.patch(existingStatus._id, {
        currentStatus: args.status,
        updatedAt: now,
      });
    } else {
      await ctx.db.insert("serviceOrderStatus", {
        orderId: args.orderId,
        currentStatus: args.status,
        updatedAt: now,
      });
    }

    return eventId;
  },
});

// ----------------------------------------------------------------------
// QUERY: lista ordens por status atual (útil para dashboards, ex: "72
// ordens abertas" no card do topo)
// ----------------------------------------------------------------------
export const countOrdersByStatus = query({
  args: {},
  handler: async (ctx) => {
    const rows = await ctx.db.query("serviceOrderStatus").collect();
    const counts: Record<string, number> = {};
    for (const status of STATUS_VALUES) counts[status] = 0;
    for (const row of rows) {
      counts[row.currentStatus] = (counts[row.currentStatus] ?? 0) + 1;
    }
    return counts;
  },
});

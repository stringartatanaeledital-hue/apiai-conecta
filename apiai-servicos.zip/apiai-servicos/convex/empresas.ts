// ============================================================================
// convex/empresas.ts
// Backend do módulo Empresas (cadastro de equipes) — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const createCompany = mutation({
  args: {
    ownerId: v.id("users"),
    name: v.string(),
    cnpj: v.optional(v.string()),
    logoStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("companies", {
      ...args,
      employeesCount: 0,
      vehiclesCount: 0,
      trucksCount: 0,
      cranesCount: 0,
      teamsCount: 0,
      createdAt: Date.now(),
    });
  },
});

export const getCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, { companyId }) => {
    const company = await ctx.db.get(companyId);
    if (!company) return null;

    const employees = await ctx.db
      .query("companyEmployees")
      .withIndex("by_company", (q) => q.eq("companyId", companyId))
      .collect();

    const vehicles = await ctx.db
      .query("companyVehicles")
      .withIndex("by_company", (q) => q.eq("companyId", companyId))
      .collect();

    const logoUrl = company.logoStorageId
      ? await ctx.storage.getUrl(company.logoStorageId)
      : null;

    return { ...company, logoUrl, employees, vehicles };
  },
});

export const listMyCompanies = query({
  args: { ownerId: v.id("users") },
  handler: async (ctx, { ownerId }) => {
    return await ctx.db
      .query("companies")
      .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
      .collect();
  },
});

export const addEmployee = mutation({
  args: {
    companyId: v.id("companies"),
    userId: v.optional(v.id("users")),
    name: v.string(),
    role: v.string(),
    teamName: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    if (!company) throw new Error("Empresa não encontrada");

    await ctx.db.patch(args.companyId, { employeesCount: company.employeesCount + 1 });
    return await ctx.db.insert("companyEmployees", { ...args, createdAt: Date.now() });
  },
});

export const addVehicle = mutation({
  args: {
    companyId: v.id("companies"),
    type: v.union(
      v.literal("veiculo"),
      v.literal("caminhao"),
      v.literal("guindaste"),
      v.literal("maquina")
    ),
    label: v.string(),
    plate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    if (!company) throw new Error("Empresa não encontrada");

    const field =
      args.type === "veiculo"
        ? "vehiclesCount"
        : args.type === "caminhao"
          ? "trucksCount"
          : args.type === "guindaste"
            ? "cranesCount"
            : "vehiclesCount";

    await ctx.db.patch(args.companyId, { [field]: (company as any)[field] + 1 });
    return await ctx.db.insert("companyVehicles", { ...args, createdAt: Date.now() });
  },
});

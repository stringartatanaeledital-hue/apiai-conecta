// ============================================================================
// convex/admin.ts — Painel Administrativo (campanhas, cupons, relatórios)
// ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// ------------------------------------------------------------------------
// CUPONS
// ------------------------------------------------------------------------
export const createCoupon = mutation({
  args: {
    code: v.string(),
    discountPercent: v.number(),
    validUntil: v.number(),
    usageLimit: v.number(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("coupons", {
      ...args,
      usedCount: 0,
      isActive: true,
      createdAt: Date.now(),
    });
  },
});

export const validateCoupon = query({
  args: { code: v.string() },
  handler: async (ctx, { code }) => {
    const coupon = await ctx.db
      .query("coupons")
      .withIndex("by_code", (q) => q.eq("code", code))
      .unique();

    if (!coupon) return { valid: false, reason: "Cupom não encontrado" };
    if (!coupon.isActive) return { valid: false, reason: "Cupom inativo" };
    if (coupon.validUntil < Date.now()) return { valid: false, reason: "Cupom expirado" };
    if (coupon.usedCount >= coupon.usageLimit)
      return { valid: false, reason: "Limite de uso atingido" };

    return { valid: true, discountPercent: coupon.discountPercent, couponId: coupon._id };
  },
});

export const useCoupon = mutation({
  args: { couponId: v.id("coupons") },
  handler: async (ctx, { couponId }) => {
    const coupon = await ctx.db.get(couponId);
    if (!coupon) throw new Error("Cupom não encontrado");
    await ctx.db.patch(couponId, { usedCount: coupon.usedCount + 1 });
  },
});

export const listCoupons = query({
  args: {},
  handler: async (ctx) => await ctx.db.query("coupons").order("desc").collect(),
});

// ------------------------------------------------------------------------
// CAMPANHAS
// ------------------------------------------------------------------------
export const createCampaign = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    startAt: v.number(),
    endAt: v.number(),
    targetAudience: v.union(
      v.literal("clientes"),
      v.literal("profissionais"),
      v.literal("ambos")
    ),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("campaigns", { ...args, isActive: true, createdAt: Date.now() });
  },
});

export const listActiveCampaigns = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("campaigns")
      .withIndex("by_isActive", (q) => q.eq("isActive", true))
      .collect();
  },
});

export const deactivateCampaign = mutation({
  args: { campaignId: v.id("campaigns") },
  handler: async (ctx, { campaignId }) => {
    await ctx.db.patch(campaignId, { isActive: false });
  },
});

// ------------------------------------------------------------------------
// RELATÓRIO GERAL (resumo da plataforma para o dashboard admin)
// ------------------------------------------------------------------------
export const getPlatformSummary = query({
  args: {},
  handler: async (ctx) => {
    const [orders, professionals, transactions, coupons, campaigns] = await Promise.all([
      ctx.db.query("serviceOrderStatus").collect(),
      ctx.db.query("users").withIndex("by_role", (q) => q.eq("role", "profissional")).collect(),
      ctx.db.query("financialTransactions").collect(),
      ctx.db.query("coupons").collect(),
      ctx.db.query("campaigns").collect(),
    ]);

    const receitaTotalCents = transactions
      .filter((t) => t.type === "receita")
      .reduce((sum, t) => sum + t.amountCents, 0);

    return {
      totalOrdens: orders.length,
      ordensAbertas: orders.filter((o) => o.currentStatus !== "concluido").length,
      totalProfissionais: professionals.length,
      receitaTotalCents,
      cuponsAtivos: coupons.filter((c) => c.isActive).length,
      campanhasAtivas: campaigns.filter((c) => c.isActive).length,
    };
  },
});

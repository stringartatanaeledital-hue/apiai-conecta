// ============================================================================
// convex/mapa.ts — Mapa Inteligente (camadas) — ATAMURA SERVIÇOS Ω
// Agrega dados de profissionais, empresas, marketplace e emergência para
// exibir como camadas no mapa. Pressupõe que "users" (role=profissional) e
// "marketplaceProducts"/sellers tenham latitude/longitude — ajuste os
// campos conforme seu schema real.
// ============================================================================

import { v } from "convex/values";
import { query } from "./_generated/server";

const layerValidator = v.union(
  v.literal("profissionais"),
  v.literal("empresas"),
  v.literal("lojas"),
  v.literal("obras"),
  v.literal("emergencia")
);

export const getLayerData = query({
  args: { layer: layerValidator },
  handler: async (ctx, { layer }) => {
    switch (layer) {
      case "profissionais": {
        const professionals = await ctx.db
          .query("users")
          .withIndex("by_role", (q) => q.eq("role", "profissional"))
          .collect();
        return professionals.map((p: any) => ({
          id: p._id,
          name: p.name,
          latitude: p.latitude,
          longitude: p.longitude,
          category: p.category,
        }));
      }
      case "empresas": {
        const companies = await ctx.db.query("companies").collect();
        return companies.map((c: any) => ({ id: c._id, name: c.name }));
      }
      case "emergencia": {
        const providers = await ctx.db.query("emergencyProviders").collect();
        return providers.map((p) => ({
          id: p._id,
          name: p.name,
          latitude: p.latitude,
          longitude: p.longitude,
          category: p.category,
          phone: p.phone,
        }));
      }
      default:
        return [];
    }
  },
});

// ============================================================================
// convex/convites.ts — Convites + aprovação manual do dono/administrador
// Apiaí Serviços
// Quem clica no link NÃO fica liberado sozinho — só cria uma solicitação.
// Só o dono decide, aprovando pelo painel (PainelConvidados.tsx).
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// ------------------------------------------------------------------------
// LINK DE CONVITE — só serve pra identificar de onde veio a solicitação
// ------------------------------------------------------------------------
export const createInviteLink = mutation({
  args: {
    code: v.string(),
    benefitDescription: v.string(),
    maxUses: v.optional(v.number()), // sem uso prático agora, mantido para o futuro
    createdBy: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("inviteLinks")
      .withIndex("by_code", (q) => q.eq("code", args.code))
      .unique();
    if (existing) throw new Error("Já existe um convite com esse código");

    return await ctx.db.insert("inviteLinks", {
      ...args,
      usedCount: 0,
      isActive: true,
      createdAt: Date.now(),
    });
  },
});

export const getInviteStatus = query({
  args: { code: v.string() },
  handler: async (ctx, { code }) => {
    const invite = await ctx.db
      .query("inviteLinks")
      .withIndex("by_code", (q) => q.eq("code", code))
      .unique();
    if (!invite) return { found: false as const };
    return {
      found: true as const,
      code: invite.code,
      benefitDescription: invite.benefitDescription,
      isActive: invite.isActive,
      inviteLinkId: invite._id,
    };
  },
});

// ------------------------------------------------------------------------
// SOLICITAÇÃO DE ACESSO — é isso que acontece quando alguém clica no link.
// Fica "pendente" até o dono aprovar ou negar.
// ------------------------------------------------------------------------
export const requestAccess = mutation({
  args: {
    userId: v.id("users"),
    code: v.optional(v.string()),
  },
  handler: async (ctx, { userId, code }) => {
    // já é convidado? não precisa solicitar de novo
    const existingGuest = await ctx.db
      .query("guestAccessGrants")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    if (existingGuest.some((g) => g.isActive)) {
      return { status: "ja_aprovado" as const };
    }

    // já tem solicitação pendente? não duplica
    const existingRequests = await ctx.db
      .query("accessRequests")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    if (existingRequests.some((r) => r.status === "pendente")) {
      return { status: "pendente" as const };
    }

    let inviteLinkId = undefined;
    if (code) {
      const invite = await ctx.db
        .query("inviteLinks")
        .withIndex("by_code", (q) => q.eq("code", code))
        .unique();
      inviteLinkId = invite?._id;
    }

    await ctx.db.insert("accessRequests", {
      userId,
      inviteLinkId,
      status: "pendente",
      requestedAt: Date.now(),
    });

    return { status: "pendente" as const };
  },
});

// Status da solicitação de UM usuário (usado na tela pública pra saber se
// já foi aprovado, negado ou continua esperando)
export const getMyRequestStatus = query({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    const isGuest = (
      await ctx.db
        .query("guestAccessGrants")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .collect()
    ).some((g) => g.isActive);
    if (isGuest) return { status: "aprovado" as const };

    const requests = await ctx.db
      .query("accessRequests")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    return { status: requests[0]?.status ?? ("nenhuma" as const) };
  },
});

// ------------------------------------------------------------------------
// PAINEL DO DONO — aprovar ou negar solicitações
// ------------------------------------------------------------------------
export const listPendingRequests = query({
  args: {},
  handler: async (ctx) => {
    const pending = await ctx.db
      .query("accessRequests")
      .withIndex("by_status", (q) => q.eq("status", "pendente"))
      .order("asc")
      .collect();

    return await Promise.all(
      pending.map(async (r) => ({ ...r, user: await ctx.db.get(r.userId) }))
    );
  },
});

export const approveRequest = mutation({
  args: {
    requestId: v.id("accessRequests"),
    benefitDescription: v.string(),
    resolvedBy: v.optional(v.id("users")),
  },
  handler: async (ctx, { requestId, benefitDescription, resolvedBy }) => {
    const request = await ctx.db.get(requestId);
    if (!request) throw new Error("Solicitação não encontrada");

    await ctx.db.patch(requestId, {
      status: "aprovado",
      resolvedAt: Date.now(),
      resolvedBy,
    });

    const existingGuest = await ctx.db
      .query("guestAccessGrants")
      .withIndex("by_user", (q) => q.eq("userId", request.userId))
      .collect();
    if (!existingGuest.some((g) => g.isActive)) {
      await ctx.db.insert("guestAccessGrants", {
        userId: request.userId,
        grantedBy: resolvedBy,
        benefitDescription,
        isActive: true,
        createdAt: Date.now(),
      });
    }
  },
});

export const denyRequest = mutation({
  args: { requestId: v.id("accessRequests"), resolvedBy: v.optional(v.id("users")) },
  handler: async (ctx, { requestId, resolvedBy }) => {
    await ctx.db.patch(requestId, {
      status: "negado",
      resolvedAt: Date.now(),
      resolvedBy,
    });
  },
});

// ------------------------------------------------------------------------
// CONVIDADOS DIRETOS — o dono adiciona alguém direto, sem passar por
// solicitação nenhuma (atalho pra quando já sabe quem quer liberar).
// ------------------------------------------------------------------------
export const addGuestAccess = mutation({
  args: {
    userId: v.id("users"),
    benefitDescription: v.string(),
    grantedBy: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("guestAccessGrants")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .collect();
    if (existing.some((g) => g.isActive)) {
      return { alreadyGuest: true };
    }

    await ctx.db.insert("guestAccessGrants", {
      ...args,
      isActive: true,
      createdAt: Date.now(),
    });
    return { alreadyGuest: false };
  },
});

export const listGuests = query({
  args: {},
  handler: async (ctx) => {
    const grants = await ctx.db.query("guestAccessGrants").order("desc").collect();
    return await Promise.all(
      grants.map(async (g) => ({ ...g, user: await ctx.db.get(g.userId) }))
    );
  },
});

export const revokeGuestAccess = mutation({
  args: { grantId: v.id("guestAccessGrants") },
  handler: async (ctx, { grantId }) => {
    await ctx.db.patch(grantId, { isActive: false });
  },
});

export const hasGuestAccess = query({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    const grants = await ctx.db
      .query("guestAccessGrants")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    return grants.some((g) => g.isActive);
  },
});

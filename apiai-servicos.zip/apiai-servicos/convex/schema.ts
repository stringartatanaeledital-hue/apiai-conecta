// ============================================================================
// convex/schema.ts — Apiaí Serviços
// Schema consolidado — TODAS as tabelas de todos os módulos num único
// arquivo, pronto para uso direto (sem precisar copiar/colar nada).
// ============================================================================

import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  // ---- de schema-adicional.ts ----
  // --------------------------------------------------------------------
  // LINHA DO TEMPO DO SERVIÇO
  // Solicitado → Orçamento → Aceito → Em execução → Concluído → Avaliação
  // --------------------------------------------------------------------
  serviceTimelineEvents: defineTable({
    orderId: v.id("serviceOrders"), // referência à ordem de serviço existente
    status: v.union(
      v.literal("solicitado"),
      v.literal("orcamento"),
      v.literal("aceito"),
      v.literal("em_execucao"),
      v.literal("concluido"),
      v.literal("avaliacao")
    ),
    title: v.string(), // ex: "Orçamento enviado"
    description: v.optional(v.string()), // ex: "R$ 4.890 - 6 dias úteis"
    actorId: v.optional(v.id("users")), // quem gerou o evento
    actorName: v.optional(v.string()),
    actorRole: v.optional(
      v.union(v.literal("cliente"), v.literal("profissional"), v.literal("sistema"))
    ),
    metadata: v.optional(v.any()), // valores extras (preço, prazo, anexos, etc.)
    createdAt: v.number(), // Date.now()
  })
    .index("by_order", ["orderId"])
    .index("by_order_and_status", ["orderId", "status"]),

  // Estado atual "cache" da ordem para consultas rápidas sem varrer eventos
  // (opcional, mas recomendado para listas e dashboards)
  serviceOrderStatus: defineTable({
    orderId: v.id("serviceOrders"),
    currentStatus: v.union(
      v.literal("solicitado"),
      v.literal("orcamento"),
      v.literal("aceito"),
      v.literal("em_execucao"),
      v.literal("concluido"),
      v.literal("avaliacao")
    ),
    updatedAt: v.number(),
  }).index("by_order", ["orderId"]),

  // --------------------------------------------------------------------
  // FEED DOS PROFISSIONAIS (estilo Instagram)
  // --------------------------------------------------------------------
  professionalPosts: defineTable({
    professionalId: v.id("users"), // referência à tabela existente
    type: v.union(
      v.literal("foto"),
      v.literal("video"),
      v.literal("antes_depois"),
      v.literal("promocao"),
      v.literal("obra")
    ),
    caption: v.optional(v.string()),
    mediaStorageIds: v.array(v.id("_storage")), // fotos/vídeo do post (carrossel)
    beforeStorageId: v.optional(v.id("_storage")), // usado quando type = antes_depois
    afterStorageId: v.optional(v.id("_storage")),
    promoDiscountPercent: v.optional(v.number()), // usado quando type = promocao
    promoValidUntil: v.optional(v.number()),
    likesCount: v.number(),
    commentsCount: v.number(),
    createdAt: v.number(),
  })
    .index("by_professional", ["professionalId"])
    .index("by_createdAt", ["createdAt"])
    .index("by_type", ["type"]),

  professionalPostLikes: defineTable({
    postId: v.id("professionalPosts"),
    userId: v.id("users"),
    createdAt: v.number(),
  })
    .index("by_post", ["postId"])
    .index("by_post_and_user", ["postId", "userId"]),

  professionalPostComments: defineTable({
    postId: v.id("professionalPosts"),
    userId: v.id("users"),
    userName: v.string(),
    text: v.string(),
    createdAt: v.number(),
  }).index("by_post", ["postId"]),

  professionalStories: defineTable({
    professionalId: v.id("users"),
    mediaStorageId: v.id("_storage"),
    mediaType: v.union(v.literal("foto"), v.literal("video")),
    createdAt: v.number(),
    expiresAt: v.number(), // createdAt + 24h
  })
    .index("by_professional", ["professionalId"])
    .index("by_expiresAt", ["expiresAt"]),

  // ---- de schema-adicional-2.ts ----
  // --------------------------------------------------------------------
  // MARKETPLACE POR DEPARTAMENTOS
  // --------------------------------------------------------------------
  marketplaceProducts: defineTable({
    sellerId: v.id("users"), // profissional ou empresa vendedora
    department: v.union(
      v.literal("ferramentas"),
      v.literal("epis"),
      v.literal("materiais"),
      v.literal("maquinas"),
      v.literal("aluguel"),
      v.literal("pecas"),
      v.literal("equipamentos")
    ),
    // Vincula o produto a uma profissão da taxonomia em
    // lib/categoriasProfissoes.ts (ex: "Pintor", "Jardineiro", "Mecânico")
    // — permite mostrar "produtos recomendados" na página de cada categoria.
    relatedProfession: v.optional(v.string()),
    name: v.string(),
    description: v.optional(v.string()),
    priceCents: v.number(), // preço em centavos, evita float
    isRental: v.boolean(),
    rentalPricePerDayCents: v.optional(v.number()),
    stock: v.number(),
    imageStorageIds: v.array(v.id("_storage")),
    isPromo: v.boolean(),
    promoDiscountPercent: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_department", ["department"])
    .index("by_seller", ["sellerId"])
    .index("by_promo", ["isPromo"])
    .index("by_relatedProfession", ["relatedProfession"]),

  marketplaceOrders: defineTable({
    productId: v.id("marketplaceProducts"),
    buyerId: v.id("users"),
    quantity: v.number(),
    totalCents: v.number(),
    status: v.union(
      v.literal("pendente"),
      v.literal("pago"),
      v.literal("enviado"),
      v.literal("entregue"),
      v.literal("cancelado")
    ),
    createdAt: v.number(),
  })
    .index("by_buyer", ["buyerId"])
    .index("by_product", ["productId"]),

  // --------------------------------------------------------------------
  // EMPRESAS (cadastro de equipes)
  // --------------------------------------------------------------------
  companies: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    cnpj: v.optional(v.string()),
    logoStorageId: v.optional(v.id("_storage")),
    employeesCount: v.number(),
    vehiclesCount: v.number(),
    trucksCount: v.number(),
    cranesCount: v.number(),
    teamsCount: v.number(),
    createdAt: v.number(),
  }).index("by_owner", ["ownerId"]),

  companyEmployees: defineTable({
    companyId: v.id("companies"),
    userId: v.optional(v.id("users")),
    name: v.string(),
    role: v.string(), // ex: "Pedreiro", "Encarregado"
    teamName: v.optional(v.string()),
    createdAt: v.number(),
  }).index("by_company", ["companyId"]),

  companyVehicles: defineTable({
    companyId: v.id("companies"),
    type: v.union(
      v.literal("veiculo"),
      v.literal("caminhao"),
      v.literal("guindaste"),
      v.literal("maquina")
    ),
    label: v.string(), // ex: "Caminhão Munck - placa ABC1234"
    plate: v.optional(v.string()),
    createdAt: v.number(),
  }).index("by_company", ["companyId"]),

  // --------------------------------------------------------------------
  // CONTRATOS (assinatura digital)
  // --------------------------------------------------------------------
  contracts: defineTable({
    orderId: v.id("serviceOrders"),
    clientId: v.id("users"),
    professionalId: v.id("users"),
    pdfStorageId: v.optional(v.id("_storage")), // PDF gerado do contrato
    qrCodeToken: v.string(), // token único para validação via QR Code
    warrantyMonths: v.optional(v.number()),
    signedByClient: v.boolean(),
    signedByClientAt: v.optional(v.number()),
    signedByProfessional: v.boolean(),
    signedByProfessionalAt: v.optional(v.number()),
    status: v.union(
      v.literal("aguardando_assinatura"),
      v.literal("assinado"),
      v.literal("cancelado")
    ),
    createdAt: v.number(),
  })
    .index("by_order", ["orderId"])
    .index("by_client", ["clientId"])
    .index("by_professional", ["professionalId"])
    .index("by_qrCodeToken", ["qrCodeToken"]),

  // --------------------------------------------------------------------
  // GAMIFICAÇÃO (medalhas)
  // --------------------------------------------------------------------
  professionalBadges: defineTable({
    professionalId: v.id("users"),
    badgeType: v.union(
      v.literal("ouro"),
      v.literal("prata"),
      v.literal("bronze"),
      v.literal("top_atendimento"),
      v.literal("super_profissional"),
      v.literal("elite")
    ),
    awardedAt: v.number(),
    reason: v.optional(v.string()), // ex: "100 serviços concluídos"
  })
    .index("by_professional", ["professionalId"])
    .index("by_badgeType", ["badgeType"]),

  // ---- de schema-adicional-3.ts ----
  // --------------------------------------------------------------------
  // PÁGINA DO PROFISSIONAL (portfólio completo)
  // --------------------------------------------------------------------
  professionalPortfolios: defineTable({
    professionalId: v.id("users"),
    videoStorageId: v.optional(v.id("_storage")), // vídeo institucional
    droneStorageId: v.optional(v.id("_storage")),
    portfolioImageIds: v.array(v.id("_storage")),
    certificates: v.array(
      v.object({ name: v.string(), storageId: v.id("_storage") })
    ),
    specialties: v.array(v.string()),
    yearsExperience: v.optional(v.number()),
    bio: v.optional(v.string()),
    resumeStorageId: v.optional(v.id("_storage")),
  }).index("by_professional", ["professionalId"]),

  // --------------------------------------------------------------------
  // ÁREA FINANCEIRA
  // --------------------------------------------------------------------
  financialTransactions: defineTable({
    ownerId: v.id("users"), // profissional, empresa ou plataforma
    type: v.union(
      v.literal("receita"),
      v.literal("despesa"),
      v.literal("comissao"),
      v.literal("pix")
    ),
    amountCents: v.number(),
    description: v.string(),
    category: v.optional(v.string()),
    invoiceStorageId: v.optional(v.id("_storage")), // nota fiscal
    createdAt: v.number(),
  })
    .index("by_owner", ["ownerId"])
    .index("by_owner_and_type", ["ownerId", "type"]),

  // --------------------------------------------------------------------
  // CURSOS
  // --------------------------------------------------------------------
  courses: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    type: v.union(v.literal("presencial"), v.literal("online")),
    category: v.string(), // ex: "Treinamento NR", "Técnico"
    isNR: v.boolean(),
    nrNumber: v.optional(v.string()), // ex: "NR-35"
    priceCents: v.number(),
    durationHours: v.number(),
    thumbnailStorageId: v.optional(v.id("_storage")),
    videoStorageIds: v.array(v.id("_storage")),
    createdAt: v.number(),
  })
    .index("by_category", ["category"])
    .index("by_isNR", ["isNR"]),

  courseEnrollments: defineTable({
    courseId: v.id("courses"),
    userId: v.id("users"),
    progressPercent: v.number(),
    completedAt: v.optional(v.number()),
    certificateStorageId: v.optional(v.id("_storage")),
    createdAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_course", ["courseId"]),

  // --------------------------------------------------------------------
  // AGENDA
  // --------------------------------------------------------------------
  agendaEvents: defineTable({
    ownerId: v.id("users"),
    title: v.string(),
    description: v.optional(v.string()),
    startAt: v.number(),
    endAt: v.number(),
    type: v.union(v.literal("servico"), v.literal("compromisso"), v.literal("bloqueio")),
    relatedOrderId: v.optional(v.id("serviceOrders")),
    createdAt: v.number(),
  })
    .index("by_owner", ["ownerId"])
    .index("by_owner_and_startAt", ["ownerId", "startAt"]),

  // --------------------------------------------------------------------
  // CENTRAL DE EMERGÊNCIA (24h)
  // --------------------------------------------------------------------
  emergencyProviders: defineTable({
    category: v.union(
      v.literal("chaveiro"),
      v.literal("guincho"),
      v.literal("eletricista"),
      v.literal("encanador")
    ),
    name: v.string(),
    phone: v.string(),
    latitude: v.number(),
    longitude: v.number(),
    isAvailable24h: v.boolean(),
    rating: v.optional(v.number()),
    createdAt: v.number(),
  }).index("by_category", ["category"]),

  // --------------------------------------------------------------------
  // SISTEMA DE FIDELIDADE
  // --------------------------------------------------------------------
  loyaltyAccounts: defineTable({
    userId: v.id("users"),
    points: v.number(),
    tier: v.union(v.literal("bronze"), v.literal("prata"), v.literal("ouro")),
    updatedAt: v.number(),
  }).index("by_user", ["userId"]),

  loyaltyTransactions: defineTable({
    userId: v.id("users"),
    points: v.number(), // positivo (ganho) ou negativo (resgate)
    reason: v.string(),
    createdAt: v.number(),
  }).index("by_user", ["userId"]),

  // --------------------------------------------------------------------
  // PAINEL ANALÍTICO DO PROFISSIONAL
  // --------------------------------------------------------------------
  profileViews: defineTable({
    professionalId: v.id("users"),
    viewerUserId: v.optional(v.id("users")),
    source: v.union(
      v.literal("busca"),
      v.literal("mapa"),
      v.literal("feed"),
      v.literal("marketplace")
    ),
    createdAt: v.number(),
  })
    .index("by_professional", ["professionalId"])
    .index("by_professional_and_createdAt", ["professionalId", "createdAt"]),

  // --------------------------------------------------------------------
  // PAINEL ADMINISTRATIVO — campanhas e cupons
  // --------------------------------------------------------------------
  coupons: defineTable({
    code: v.string(),
    discountPercent: v.number(),
    validUntil: v.number(),
    usageLimit: v.number(),
    usedCount: v.number(),
    isActive: v.boolean(),
    createdAt: v.number(),
  }).index("by_code", ["code"]),

  campaigns: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    startAt: v.number(),
    endAt: v.number(),
    targetAudience: v.union(
      v.literal("clientes"),
      v.literal("profissionais"),
      v.literal("ambos")
    ),
    isActive: v.boolean(),
    createdAt: v.number(),
  }).index("by_isActive", ["isActive"]),

  // ---- de schema-adicional-5.ts ----
  inviteLinks: defineTable({
    code: v.string(), // ex: "APIAI50"
    createdBy: v.optional(v.id("users")),
    benefitDescription: v.string(), // ex: "Acesso Premium grátis por 6 meses"
    maxUses: v.optional(v.number()), // deixe em branco/undefined para ilimitado
    usedCount: v.number(),
    isActive: v.boolean(),
    createdAt: v.number(),
  }).index("by_code", ["code"]),

  // --------------------------------------------------------------------
  // SOLICITAÇÕES DE ACESSO GRATUITO — quem clica no link só fica liberado
  // depois que o dono/administrador aprova manualmente.
  // --------------------------------------------------------------------
  accessRequests: defineTable({
    userId: v.id("users"),
    inviteLinkId: v.optional(v.id("inviteLinks")),
    status: v.union(v.literal("pendente"), v.literal("aprovado"), v.literal("negado")),
    requestedAt: v.number(),
    resolvedAt: v.optional(v.number()),
    resolvedBy: v.optional(v.id("users")),
  })
    .index("by_user", ["userId"])
    .index("by_status", ["status"]),

  // --------------------------------------------------------------------
  // CONVIDADOS — acesso gratuito sem limite de quantidade. Só existe depois
  // que o dono/administrador aprova (via accessRequests) ou adiciona
  // diretamente pelo painel.
  // --------------------------------------------------------------------
  guestAccessGrants: defineTable({
    userId: v.id("users"),
    grantedBy: v.optional(v.id("users")),
    benefitDescription: v.string(),
    isActive: v.boolean(),
    createdAt: v.number(),
  }).index("by_user", ["userId"]),

  // ---- de schema-adicional-6.ts ----
  // --------------------------------------------------------------------
  // USUÁRIOS (cadastro)
  // Observação de segurança: NUNCA guarde senha em texto puro. O ideal é
  // usar Convex Auth, Clerk ou Auth.js integrados ao Convex. O campo
  // passwordHash abaixo pressupõe que você já fez o hash (ex: bcrypt) antes
  // de chamar a mutation — nunca hasheie no cliente nem grave a senha crua.
  // --------------------------------------------------------------------
  users: defineTable({
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    passwordHash: v.string(),
    role: v.union(v.literal("cliente"), v.literal("profissional"), v.literal("empresa"), v.literal("admin")),
    photoStorageId: v.optional(v.id("_storage")),
    cityLabel: v.optional(v.string()),
    // Preenchidos quando role = "profissional", via CadastroProfissional.tsx
    category: v.optional(v.string()), // ex: "construcao_reforma"
    subcategory: v.optional(v.string()), // ex: "Pintor"
    rating: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_email", ["email"])
    .index("by_role", ["role"]),

  // --------------------------------------------------------------------
  // CHAT DIRETO entre cliente e profissional
  // --------------------------------------------------------------------
  conversations: defineTable({
    clientId: v.id("users"),
    professionalId: v.id("users"),
    lastMessagePreview: v.optional(v.string()),
    lastMessageAt: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_client", ["clientId"])
    .index("by_professional", ["professionalId"]),

  chatMessages: defineTable({
    conversationId: v.id("conversations"),
    senderId: v.id("users"),
    text: v.optional(v.string()),
    imageStorageId: v.optional(v.id("_storage")),
    readAt: v.optional(v.number()),
    createdAt: v.number(),
  }).index("by_conversation", ["conversationId"]),

  // --------------------------------------------------------------------
  // GALERIA DE SERVIÇOS COM FOTOS — usada por marcenarias e qualquer
  // profissional/empresa que queira mostrar trabalhos feitos, com preço.
  // --------------------------------------------------------------------
  serviceGalleryItems: defineTable({
    ownerId: v.id("users"), // profissional, marcenaria ou empresa
    ownerType: v.union(v.literal("profissional"), v.literal("empresa")),
    title: v.string(), // ex: "Guarda-roupa planejado 6 portas"
    description: v.optional(v.string()),
    category: v.optional(v.string()), // ex: "Marcenaria", "Móveis planejados"
    priceCents: v.optional(v.number()),
    imageStorageIds: v.array(v.id("_storage")),
    createdAt: v.number(),
  })
    .index("by_owner", ["ownerId"])
    .index("by_category", ["category"]),

  // ---- de schema-adicional-7.ts ----
  // --------------------------------------------------------------------
  // PEDIDOS DE SERVIÇO — criado pelo cliente quando solicita um serviço
  // pela primeira vez. A Linha do Tempo (serviceTimelineEvents) usa o _id
  // desta tabela como orderId.
  // --------------------------------------------------------------------
  serviceOrders: defineTable({
    clientId: v.id("users"),
    professionalId: v.optional(v.id("users")), // preenchido quando um profissional aceita
    category: v.string(), // ex: "construcao_reforma"
    subcategory: v.string(), // ex: "Pintor"
    description: v.string(),
    addressText: v.optional(v.string()),
    budgetMinCents: v.optional(v.number()),
    budgetMaxCents: v.optional(v.number()),
    photoStorageIds: v.array(v.id("_storage")),
    createdAt: v.number(),
  })
    .index("by_client", ["clientId"])
    .index("by_professional", ["professionalId"])
    .index("by_category", ["category"]),

  // --------------------------------------------------------------------
  // AVALIAÇÕES — cliente avalia o profissional após o serviço concluído
  // --------------------------------------------------------------------
  reviews: defineTable({
    orderId: v.id("serviceOrders"),
    clientId: v.id("users"),
    professionalId: v.id("users"),
    rating: v.number(), // 1 a 5
    comment: v.optional(v.string()),
    createdAt: v.number(),
  })
    .index("by_professional", ["professionalId"])
    .index("by_order", ["orderId"])
    .index("by_client", ["clientId"]),

  // --------------------------------------------------------------------
  // CATEGORIAS CUSTOMIZADAS — profissões extras adicionadas pelo painel
  // admin, além das já existentes em lib/categoriasProfissoes.ts
  // --------------------------------------------------------------------
  customCategories: defineTable({
    departmentKey: v.string(), // vincula a um departamento existente, ex: "construcao_reforma"
    profession: v.string(), // ex: "Instalador de piso vinílico"
    addedBy: v.optional(v.id("users")),
    createdAt: v.number(),
  }).index("by_departmentKey", ["departmentKey"]),
});

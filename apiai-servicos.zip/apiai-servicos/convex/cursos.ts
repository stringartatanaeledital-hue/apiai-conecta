// ============================================================================
// convex/cursos.ts — Cursos e Treinamentos NR — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => await ctx.storage.generateUploadUrl(),
});

export const createCourse = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    type: v.union(v.literal("presencial"), v.literal("online")),
    category: v.string(),
    isNR: v.boolean(),
    nrNumber: v.optional(v.string()),
    priceCents: v.number(),
    durationHours: v.number(),
    thumbnailStorageId: v.optional(v.id("_storage")),
    videoStorageIds: v.array(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("courses", { ...args, createdAt: Date.now() });
  },
});

export const listCourses = query({
  args: { category: v.optional(v.string()), onlyNR: v.optional(v.boolean()) },
  handler: async (ctx, { category, onlyNR }) => {
    let courses = onlyNR
      ? await ctx.db.query("courses").withIndex("by_isNR", (q) => q.eq("isNR", true)).collect()
      : await ctx.db.query("courses").collect();

    if (category) courses = courses.filter((c) => c.category === category);

    return await Promise.all(
      courses.map(async (c) => ({
        ...c,
        thumbnailUrl: c.thumbnailStorageId ? await ctx.storage.getUrl(c.thumbnailStorageId) : null,
      }))
    );
  },
});

export const enroll = mutation({
  args: { courseId: v.id("courses"), userId: v.id("users") },
  handler: async (ctx, { courseId, userId }) => {
    const existing = await ctx.db
      .query("courseEnrollments")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    if (existing.some((e) => e.courseId === courseId)) return { alreadyEnrolled: true };

    await ctx.db.insert("courseEnrollments", {
      courseId,
      userId,
      progressPercent: 0,
      createdAt: Date.now(),
    });
    return { alreadyEnrolled: false };
  },
});

export const updateProgress = mutation({
  args: {
    enrollmentId: v.id("courseEnrollments"),
    progressPercent: v.number(),
    certificateStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, { enrollmentId, progressPercent, certificateStorageId }) => {
    const patch: Record<string, unknown> = { progressPercent };
    if (progressPercent >= 100) {
      patch.completedAt = Date.now();
      if (certificateStorageId) patch.certificateStorageId = certificateStorageId;
    }
    await ctx.db.patch(enrollmentId, patch);
  },
});

export const listMyEnrollments = query({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    const enrollments = await ctx.db
      .query("courseEnrollments")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    return await Promise.all(
      enrollments.map(async (e) => ({
        ...e,
        course: await ctx.db.get(e.courseId),
      }))
    );
  },
});

// ============================================================================
// convex/galeriaServicos.ts — Galeria de serviços com fotos
// Usado por marcenarias e qualquer profissional/empresa — Apiaí Serviços
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => await ctx.storage.generateUploadUrl(),
});

export const addGalleryItem = mutation({
  args: {
    ownerId: v.id("users"),
    ownerType: v.union(v.literal("profissional"), v.literal("empresa")),
    title: v.string(),
    description: v.optional(v.string()),
    category: v.optional(v.string()),
    priceCents: v.optional(v.number()),
    imageStorageIds: v.array(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("serviceGalleryItems", { ...args, createdAt: Date.now() });
  },
});

export const listByOwner = query({
  args: { ownerId: v.id("users") },
  handler: async (ctx, { ownerId }) => {
    const items = await ctx.db
      .query("serviceGalleryItems")
      .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
      .order("desc")
      .collect();

    return await Promise.all(
      items.map(async (item) => ({
        ...item,
        imageUrls: await Promise.all(item.imageStorageIds.map((id) => ctx.storage.getUrl(id))),
      }))
    );
  },
});

// Vitrine geral por categoria — ex: todas as marcenarias da região
export const listByCategory = query({
  args: { category: v.string() },
  handler: async (ctx, { category }) => {
    const items = await ctx.db
      .query("serviceGalleryItems")
      .withIndex("by_category", (q) => q.eq("category", category))
      .order("desc")
      .collect();

    return await Promise.all(
      items.map(async (item) => {
        const owner = await ctx.db.get(item.ownerId);
        return {
          ...item,
          imageUrls: await Promise.all(item.imageStorageIds.map((id) => ctx.storage.getUrl(id))),
          ownerName: (owner as any)?.name ?? "Profissional",
        };
      })
    );
  },
});

export const deleteGalleryItem = mutation({
  args: { itemId: v.id("serviceGalleryItems") },
  handler: async (ctx, { itemId }) => {
    await ctx.db.delete(itemId);
  },
});

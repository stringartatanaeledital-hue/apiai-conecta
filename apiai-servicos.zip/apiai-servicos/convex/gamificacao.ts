// ============================================================================
// convex/gamificacao.ts
// Backend do módulo Gamificação (medalhas) — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const badgeValidator = v.union(
  v.literal("ouro"),
  v.literal("prata"),
  v.literal("bronze"),
  v.literal("top_atendimento"),
  v.literal("super_profissional"),
  v.literal("elite")
);

export const BADGE_LABELS: Record<string, string> = {
  ouro: "Ouro",
  prata: "Prata",
  bronze: "Bronze",
  top_atendimento: "Top atendimento",
  super_profissional: "Super profissional",
  elite: "Elite",
};

export const awardBadge = mutation({
  args: {
    professionalId: v.id("users"),
    badgeType: badgeValidator,
    reason: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // evita duplicar a mesma medalha para o mesmo profissional
    const existing = await ctx.db
      .query("professionalBadges")
      .withIndex("by_professional", (q) => q.eq("professionalId", args.professionalId))
      .collect();

    if (existing.some((b) => b.badgeType === args.badgeType)) {
      return { alreadyAwarded: true };
    }

    await ctx.db.insert("professionalBadges", { ...args, awardedAt: Date.now() });
    return { alreadyAwarded: false };
  },
});

export const listBadgesByProfessional = query({
  args: { professionalId: v.id("users") },
  handler: async (ctx, { professionalId }) => {
    return await ctx.db
      .query("professionalBadges")
      .withIndex("by_professional", (q) => q.eq("professionalId", professionalId))
      .order("desc")
      .collect();
  },
});

// Ranking simples: profissionais com mais medalhas
export const topRankedProfessionals = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, { limit = 10 }) => {
    const allBadges = await ctx.db.query("professionalBadges").collect();
    const countByProfessional: Record<string, number> = {};
    for (const b of allBadges) {
      countByProfessional[b.professionalId] = (countByProfessional[b.professionalId] ?? 0) + 1;
    }

    const sorted = Object.entries(countByProfessional)
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit);

    return await Promise.all(
      sorted.map(async ([professionalId, badgeCount]) => {
        const professional = await ctx.db.get(professionalId as any);
        return {
          professionalId,
          badgeCount,
          name: (professional as any)?.name ?? "Profissional",
          photoUrl: (professional as any)?.photoUrl ?? null,
        };
      })
    );
  },
});

// Regra simples de concessão automática de medalha por número de serviços
// concluídos. Chame isso, por exemplo, sempre que uma ordem for concluída.
export const evaluateAutoBadges = mutation({
  args: {
    professionalId: v.id("users"),
    completedServicesCount: v.number(),
    averageRating: v.number(),
  },
  handler: async (ctx, { professionalId, completedServicesCount, averageRating }) => {
    const awarded: string[] = [];

    async function tryAward(badgeType: string, reason: string) {
      const existing = await ctx.db
        .query("professionalBadges")
        .withIndex("by_professional", (q) => q.eq("professionalId", professionalId))
        .collect();
      if (existing.some((b) => b.badgeType === badgeType)) return;
      await ctx.db.insert("professionalBadges", {
        professionalId,
        badgeType: badgeType as any,
        reason,
        awardedAt: Date.now(),
      });
      awarded.push(badgeType);
    }

    if (completedServicesCount >= 10) await tryAward("bronze", "10 serviços concluídos");
    if (completedServicesCount >= 50) await tryAward("prata", "50 serviços concluídos");
    if (completedServicesCount >= 150) await tryAward("ouro", "150 serviços concluídos");
    if (averageRating >= 4.8 && completedServicesCount >= 30)
      await tryAward("top_atendimento", "Nota média acima de 4.8");
    if (completedServicesCount >= 300 && averageRating >= 4.9)
      await tryAward("elite", "300+ serviços com nota média acima de 4.9");

    return { awarded };
  },
});

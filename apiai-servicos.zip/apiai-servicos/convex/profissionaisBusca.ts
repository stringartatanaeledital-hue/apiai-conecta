// ============================================================================
// convex/profissionaisBusca.ts — Apiaí Serviços
// Busca de profissionais usando a taxonomia de lib/categoriasProfissoes.ts
// Pressupõe que a tabela "users" tenha os campos (para role="profissional"):
//   category: string       (ex: "construcao_reforma")
//   subcategory: string    (ex: "Pintor")
// Ajuste os nomes de campo abaixo se o seu schema usar nomes diferentes.
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// Atualiza a categoria/profissão de um profissional (usado no cadastro de perfil)
export const updateCategory = mutation({
  args: {
    professionalId: v.id("users"),
    category: v.string(),
    subcategory: v.string(),
  },
  handler: async (ctx, { professionalId, category, subcategory }) => {
    await ctx.db.patch(professionalId, { category, subcategory } as any);
  },
});

export const searchProfessionals = query({
  args: {
    category: v.optional(v.string()),
    subcategory: v.optional(v.string()),
    searchText: v.optional(v.string()),
  },
  handler: async (ctx, { category, subcategory, searchText }) => {
    let professionals = (
      await ctx.db
        .query("users")
        .withIndex("by_role", (q) => q.eq("role", "profissional"))
        .collect()
    ) as any[];

    if (category) {
      professionals = professionals.filter((p: any) => p.category === category);
    }
    if (subcategory) {
      professionals = professionals.filter((p: any) => p.subcategory === subcategory);
    }
    if (searchText) {
      const term = searchText.toLowerCase();
      professionals = professionals.filter(
        (p: any) =>
          p.name?.toLowerCase().includes(term) ||
          p.subcategory?.toLowerCase().includes(term) ||
          p.category?.toLowerCase().includes(term)
      );
    }

    return professionals;
  },
});

// Contagem de profissionais por departamento — usado nos cards da tela do
// cliente para mostrar "128 pintores", "42 jardineiros", etc.
export const countBySubcategory = query({
  args: {},
  handler: async (ctx) => {
    const professionals = await ctx.db
      .query("users")
      .withIndex("by_role", (q) => q.eq("role", "profissional"))
      .collect();
    const counts: Record<string, number> = {};
    for (const p of professionals as any[]) {
      if (!p.subcategory) continue;
      counts[p.subcategory] = (counts[p.subcategory] ?? 0) + 1;
    }
    return counts;
  },
});

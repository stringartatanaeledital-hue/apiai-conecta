// ============================================================================
// convex/fidelidade.ts — Sistema de Fidelidade — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

function tierFor(points: number): "bronze" | "prata" | "ouro" {
  if (points >= 5000) return "ouro";
  if (points >= 1500) return "prata";
  return "bronze";
}

export const getAccount = query({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    const account = await ctx.db
      .query("loyaltyAccounts")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
    return account ?? { userId, points: 0, tier: "bronze" as const, updatedAt: 0 };
  },
});

export const addPoints = mutation({
  args: { userId: v.id("users"), points: v.number(), reason: v.string() },
  handler: async (ctx, { userId, points, reason }) => {
    await ctx.db.insert("loyaltyTransactions", { userId, points, reason, createdAt: Date.now() });

    const existing = await ctx.db
      .query("loyaltyAccounts")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    const newTotal = Math.max(0, (existing?.points ?? 0) + points);
    const tier = tierFor(newTotal);

    if (existing) {
      await ctx.db.patch(existing._id, { points: newTotal, tier, updatedAt: Date.now() });
    } else {
      await ctx.db.insert("loyaltyAccounts", {
        userId,
        points: newTotal,
        tier,
        updatedAt: Date.now(),
      });
    }
    return { points: newTotal, tier };
  },
});

export const listHistory = query({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    return await ctx.db
      .query("loyaltyTransactions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

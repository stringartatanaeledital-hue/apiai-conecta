// ============================================================================
// convex/auth.ts — Cadastro de usuário — Apiaí Serviços
//
// IMPORTANTE SOBRE SEGURANÇA: este arquivo mostra a estrutura de dados e as
// operações de cadastro/login, mas a Convex Actions é onde você deve rodar
// bcrypt (Convex "mutation" não roda bibliotecas nativas de hash). Use uma
// "action" para gerar o hash da senha antes de gravar. Para produção real,
// o caminho mais seguro e rápido é usar Convex Auth
// (https://labs.convex.dev/auth) ou Clerk/Auth.js integrados — eles cuidam
// de hash de senha, sessão, recuperação de senha, etc. automaticamente.
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const checkEmailAvailable = query({
  args: { email: v.string() },
  handler: async (ctx, { email }) => {
    const existing = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", email.toLowerCase()))
      .unique();
    return { available: !existing };
  },
});

// Chame esta mutation DEPOIS de gerar o hash da senha (ex: numa Convex
// Action com bcryptjs, ou no seu backend de auth) — nunca grave senha crua.
export const registerUser = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    passwordHash: v.string(),
    role: v.union(v.literal("cliente"), v.literal("profissional"), v.literal("empresa")),
    cityLabel: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const email = args.email.toLowerCase().trim();
    const existing = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", email))
      .unique();
    if (existing) throw new Error("Já existe uma conta com esse e-mail");

    return await ctx.db.insert("users", {
      ...args,
      email,
      createdAt: Date.now(),
    });
  },
});

export const getUserByEmail = query({
  args: { email: v.string() },
  handler: async (ctx, { email }) => {
    return await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", email.toLowerCase()))
      .unique();
  },
});

// Login: valide a senha numa Convex Action (comparando o hash com
// bcrypt.compare) e só então confirme aqui. Esta query só busca os dados —
// a checagem de senha deve acontecer ANTES de considerar o login válido.
// Veja o exemplo de Action no final de CadastroUsuario.tsx.
export const getUserForLogin = query({
  args: { email: v.string() },
  handler: async (ctx, { email }) => {
    const user = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", email.toLowerCase()))
      .unique();
    if (!user) return null;
    // Retorna o hash pra Action comparar — nunca exponha isso direto pro
    // cliente final sem essa comparação ter acontecido no servidor.
    return {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      passwordHash: user.passwordHash,
    };
  },
});

export const updateProfile = mutation({
  args: {
    userId: v.id("users"),
    name: v.optional(v.string()),
    phone: v.optional(v.string()),
    photoStorageId: v.optional(v.id("_storage")),
    cityLabel: v.optional(v.string()),
  },
  handler: async (ctx, { userId, ...patch }) => {
    await ctx.db.patch(userId, patch);
  },
});

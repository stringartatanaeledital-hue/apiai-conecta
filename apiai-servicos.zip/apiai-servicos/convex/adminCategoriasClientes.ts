// ============================================================================
// convex/adminCategoriasClientes.ts — Apiaí Serviços
// Categorias customizadas (profissões extras) + listagem de clientes,
// pro painel administrativo.
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// ------------------------------------------------------------------------
// CATEGORIAS CUSTOMIZADAS — profissões extras além das que já existem em
// lib/categoriasProfissoes.ts, adicionadas pelo painel sem mexer no código.
// ------------------------------------------------------------------------
export const addCustomCategory = mutation({
  args: {
    departmentKey: v.string(),
    profession: v.string(),
    addedBy: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("customCategories", { ...args, createdAt: Date.now() });
  },
});

export const listCustomCategories = query({
  args: { departmentKey: v.optional(v.string()) },
  handler: async (ctx, { departmentKey }) => {
    if (departmentKey) {
      return await ctx.db
        .query("customCategories")
        .withIndex("by_departmentKey", (q) => q.eq("departmentKey", departmentKey))
        .collect();
    }
    return await ctx.db.query("customCategories").collect();
  },
});

export const removeCustomCategory = mutation({
  args: { categoryId: v.id("customCategories") },
  handler: async (ctx, { categoryId }) => {
    await ctx.db.delete(categoryId);
  },
});

// ------------------------------------------------------------------------
// CLIENTES — listagem/gestão simples pro painel admin
// ------------------------------------------------------------------------
export const listClients = query({
  args: { searchText: v.optional(v.string()) },
  handler: async (ctx, { searchText }) => {
    let clients = await ctx.db
      .query("users")
      .withIndex("by_role", (q) => q.eq("role", "cliente"))
      .collect();

    if (searchText) {
      const term = searchText.toLowerCase();
      clients = clients.filter(
        (c) => c.name.toLowerCase().includes(term) || c.email.toLowerCase().includes(term)
      );
    }

    return clients.map((c) => ({
      _id: c._id,
      name: c.name,
      email: c.email,
      phone: c.phone,
      cityLabel: c.cityLabel,
      createdAt: c.createdAt,
    }));
  },
});

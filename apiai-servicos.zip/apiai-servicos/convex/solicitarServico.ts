// ============================================================================
// convex/solicitarServico.ts — Apiaí Serviços
// Criação do pedido de serviço pelo cliente (primeira etapa, antes de
// existir orçamento). Ao criar, já registra o primeiro evento na Linha do
// Tempo com status "solicitado".
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => await ctx.storage.generateUploadUrl(),
});

export const createServiceOrder = mutation({
  args: {
    clientId: v.id("users"),
    category: v.string(),
    subcategory: v.string(),
    description: v.string(),
    addressText: v.optional(v.string()),
    budgetMinCents: v.optional(v.number()),
    budgetMaxCents: v.optional(v.number()),
    photoStorageIds: v.array(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const orderId = await ctx.db.insert("serviceOrders", { ...args, createdAt: Date.now() });

    // Primeiro evento da linha do tempo
    const now = Date.now();
    await ctx.db.insert("serviceTimelineEvents", {
      orderId,
      status: "solicitado",
      title: "Serviço solicitado",
      description: args.description,
      actorId: args.clientId,
      actorRole: "cliente",
      createdAt: now,
    });
    await ctx.db.insert("serviceOrderStatus", {
      orderId,
      currentStatus: "solicitado",
      updatedAt: now,
    });

    return orderId;
  },
});

// Pedidos abertos de uma categoria/profissão — profissionais usam isso pra
// ver quais solicitações podem atender e enviar orçamento
export const listOpenOrdersBySubcategory = query({
  args: { subcategory: v.string() },
  handler: async (ctx, { subcategory }) => {
    const orders = await ctx.db.query("serviceOrders").collect();
    const filtered = orders.filter((o) => o.subcategory === subcategory && !o.professionalId);

    return await Promise.all(
      filtered.map(async (o) => {
        const client = await ctx.db.get(o.clientId);
        return {
          ...o,
          clientName: (client as any)?.name ?? "Cliente",
          photoUrls: await Promise.all(o.photoStorageIds.map((id) => ctx.storage.getUrl(id))),
        };
      })
    );
  },
});

export const listMyOrders = query({
  args: { clientId: v.id("users") },
  handler: async (ctx, { clientId }) => {
    return await ctx.db
      .query("serviceOrders")
      .withIndex("by_client", (q) => q.eq("clientId", clientId))
      .order("desc")
      .collect();
  },
});

// Profissional aceita atender o pedido (some da lista de abertos)
export const assignProfessional = mutation({
  args: { orderId: v.id("serviceOrders"), professionalId: v.id("users") },
  handler: async (ctx, { orderId, professionalId }) => {
    await ctx.db.patch(orderId, { professionalId });
    await ctx.db.insert("serviceTimelineEvents", {
      orderId,
      status: "orcamento",
      title: "Profissional aceitou atender",
      actorId: professionalId,
      actorRole: "profissional",
      createdAt: Date.now(),
    });
    const statusRow = await ctx.db
      .query("serviceOrderStatus")
      .withIndex("by_order", (q) => q.eq("orderId", orderId))
      .unique();
    if (statusRow) {
      await ctx.db.patch(statusRow._id, { currentStatus: "orcamento", updatedAt: Date.now() });
    }
  },
});

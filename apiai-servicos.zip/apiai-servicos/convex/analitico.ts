// ============================================================================
// convex/analitico.ts — Painel Analítico do Profissional — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const sourceValidator = v.union(
  v.literal("busca"),
  v.literal("mapa"),
  v.literal("feed"),
  v.literal("marketplace")
);

export const registerView = mutation({
  args: {
    professionalId: v.id("users"),
    viewerUserId: v.optional(v.id("users")),
    source: sourceValidator,
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("profileViews", { ...args, createdAt: Date.now() });
  },
});

export const getAnalytics = query({
  args: { professionalId: v.id("users"), days: v.optional(v.number()) },
  handler: async (ctx, { professionalId, days = 30 }) => {
    const since = Date.now() - days * 24 * 60 * 60 * 1000;
    const views = await ctx.db
      .query("profileViews")
      .withIndex("by_professional_and_createdAt", (q) =>
        q.eq("professionalId", professionalId).gte("createdAt", since)
      )
      .collect();

    const bySource: Record<string, number> = {};
    for (const v of views) bySource[v.source] = (bySource[v.source] ?? 0) + 1;

    // Contatos gerados = visualizações vindas de usuários logados (proxy simples)
    const contactsGenerated = views.filter((v) => v.viewerUserId).length;
    const conversionRate = views.length > 0 ? (contactsGenerated / views.length) * 100 : 0;

    // série diária de visualizações
    const byDay: Record<string, number> = {};
    for (const v of views) {
      const day = new Date(v.createdAt).toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
      });
      byDay[day] = (byDay[day] ?? 0) + 1;
    }

    return {
      totalViews: views.length,
      bySource,
      contactsGenerated,
      conversionRate: Math.round(conversionRate * 10) / 10,
      timeline: Object.entries(byDay).map(([day, count]) => ({ day, count })),
    };
  },
});

// ============================================================================
// convex/portfolio.ts — Página do Profissional — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => await ctx.storage.generateUploadUrl(),
});

export const upsertPortfolio = mutation({
  args: {
    professionalId: v.id("users"),
    videoStorageId: v.optional(v.id("_storage")),
    droneStorageId: v.optional(v.id("_storage")),
    portfolioImageIds: v.array(v.id("_storage")),
    certificates: v.array(v.object({ name: v.string(), storageId: v.id("_storage") })),
    specialties: v.array(v.string()),
    yearsExperience: v.optional(v.number()),
    bio: v.optional(v.string()),
    resumeStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("professionalPortfolios")
      .withIndex("by_professional", (q) => q.eq("professionalId", args.professionalId))
      .unique();

    if (existing) {
      await ctx.db.patch(existing._id, args);
      return existing._id;
    }
    return await ctx.db.insert("professionalPortfolios", args);
  },
});

export const getPortfolio = query({
  args: { professionalId: v.id("users") },
  handler: async (ctx, { professionalId }) => {
    const professional = await ctx.db.get(professionalId);
    if (!professional) return null;

    const portfolio = await ctx.db
      .query("professionalPortfolios")
      .withIndex("by_professional", (q) => q.eq("professionalId", professionalId))
      .unique();

    const videoUrl = portfolio?.videoStorageId
      ? await ctx.storage.getUrl(portfolio.videoStorageId)
      : null;
    const droneUrl = portfolio?.droneStorageId
      ? await ctx.storage.getUrl(portfolio.droneStorageId)
      : null;
    const portfolioImageUrls = portfolio
      ? await Promise.all(portfolio.portfolioImageIds.map((id) => ctx.storage.getUrl(id)))
      : [];
    const certificateUrls = portfolio
      ? await Promise.all(
          portfolio.certificates.map(async (c) => ({
            name: c.name,
            url: await ctx.storage.getUrl(c.storageId),
          }))
        )
      : [];

    return {
      professional,
      portfolio: portfolio
        ? { ...portfolio, videoUrl, droneUrl, portfolioImageUrls, certificateUrls }
        : null,
    };
  },
});

// ============================================================================
// convex/chat.ts — Chat direto entre cliente e profissional
// Apiaí Serviços
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => await ctx.storage.generateUploadUrl(),
});

// Cria a conversa se ainda não existir, ou retorna a existente
export const getOrCreateConversation = mutation({
  args: { clientId: v.id("users"), professionalId: v.id("users") },
  handler: async (ctx, { clientId, professionalId }) => {
    const existing = await ctx.db
      .query("conversations")
      .withIndex("by_client", (q) => q.eq("clientId", clientId))
      .collect();

    const found = existing.find((c) => c.professionalId === professionalId);
    if (found) return found._id;

    return await ctx.db.insert("conversations", {
      clientId,
      professionalId,
      createdAt: Date.now(),
    });
  },
});

export const sendMessage = mutation({
  args: {
    conversationId: v.id("conversations"),
    senderId: v.id("users"),
    text: v.optional(v.string()),
    imageStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const messageId = await ctx.db.insert("chatMessages", { ...args, createdAt: Date.now() });

    await ctx.db.patch(args.conversationId, {
      lastMessagePreview: args.text ?? "📷 Foto",
      lastMessageAt: Date.now(),
    });

    return messageId;
  },
});

export const listMessages = query({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, { conversationId }) => {
    const messages = await ctx.db
      .query("chatMessages")
      .withIndex("by_conversation", (q) => q.eq("conversationId", conversationId))
      .order("asc")
      .collect();

    return await Promise.all(
      messages.map(async (m) => ({
        ...m,
        imageUrl: m.imageStorageId ? await ctx.storage.getUrl(m.imageStorageId) : null,
      }))
    );
  },
});

export const markAsRead = mutation({
  args: { conversationId: v.id("conversations"), readerId: v.id("users") },
  handler: async (ctx, { conversationId, readerId }) => {
    const messages = await ctx.db
      .query("chatMessages")
      .withIndex("by_conversation", (q) => q.eq("conversationId", conversationId))
      .collect();

    const now = Date.now();
    for (const m of messages) {
      if (m.senderId !== readerId && !m.readAt) {
        await ctx.db.patch(m._id, { readAt: now });
      }
    }
  },
});

// Lista de conversas de um usuário (funciona pra cliente OU profissional)
export const listMyConversations = query({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    const asClient = await ctx.db
      .query("conversations")
      .withIndex("by_client", (q) => q.eq("clientId", userId))
      .collect();
    const asProfessional = await ctx.db
      .query("conversations")
      .withIndex("by_professional", (q) => q.eq("professionalId", userId))
      .collect();

    const all = [...asClient, ...asProfessional].sort(
      (a, b) => (b.lastMessageAt ?? b.createdAt) - (a.lastMessageAt ?? a.createdAt)
    );

    return await Promise.all(
      all.map(async (c) => {
        const otherUserId = c.clientId === userId ? c.professionalId : c.clientId;
        const otherUser = await ctx.db.get(otherUserId);

        const unreadMessages = await ctx.db
          .query("chatMessages")
          .withIndex("by_conversation", (q) => q.eq("conversationId", c._id))
          .collect();
        const unreadCount = unreadMessages.filter(
          (m) => m.senderId !== userId && !m.readAt
        ).length;

        return {
          ...c,
          otherUserName: (otherUser as any)?.name ?? "Usuário",
          otherUserPhotoUrl: (otherUser as any)?.photoStorageId
            ? await ctx.storage.getUrl((otherUser as any).photoStorageId)
            : null,
          unreadCount,
        };
      })
    );
  },
});

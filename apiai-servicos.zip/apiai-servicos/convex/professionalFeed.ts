// ============================================================================
// convex/professionalFeed.ts
// Backend do Feed dos Profissionais (estilo Instagram) — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const postTypeValidator = v.union(
  v.literal("foto"),
  v.literal("video"),
  v.literal("antes_depois"),
  v.literal("promocao"),
  v.literal("obra")
);

// ----------------------------------------------------------------------
// MUTATION: gera URL de upload direto para o Convex Storage
// Chame isso no frontend antes de subir a foto/vídeo do post.
// ----------------------------------------------------------------------
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

// ----------------------------------------------------------------------
// MUTATION: cria um novo post no feed
// ----------------------------------------------------------------------
export const createPost = mutation({
  args: {
    professionalId: v.id("users"),
    type: postTypeValidator,
    caption: v.optional(v.string()),
    mediaStorageIds: v.array(v.id("_storage")),
    beforeStorageId: v.optional(v.id("_storage")),
    afterStorageId: v.optional(v.id("_storage")),
    promoDiscountPercent: v.optional(v.number()),
    promoValidUntil: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("professionalPosts", {
      ...args,
      likesCount: 0,
      commentsCount: 0,
      createdAt: Date.now(),
    });
  },
});

// ----------------------------------------------------------------------
// QUERY: feed paginado, mais recentes primeiro
// ----------------------------------------------------------------------
export const listFeed = query({
  args: { paginationOpts: v.any() },
  handler: async (ctx, { paginationOpts }) => {
    const page = await ctx.db
      .query("professionalPosts")
      .withIndex("by_createdAt")
      .order("desc")
      .paginate(paginationOpts);

    // Resolve URLs de mídia e dados do profissional para cada post
    const items = await Promise.all(
      page.page.map(async (post) => {
        const professional = await ctx.db.get(post.professionalId);
        const mediaUrls = await Promise.all(
          post.mediaStorageIds.map((id) => ctx.storage.getUrl(id))
        );
        const beforeUrl = post.beforeStorageId
          ? await ctx.storage.getUrl(post.beforeStorageId)
          : null;
        const afterUrl = post.afterStorageId
          ? await ctx.storage.getUrl(post.afterStorageId)
          : null;

        return {
          ...post,
          mediaUrls,
          beforeUrl,
          afterUrl,
          professionalName: professional?.name ?? "Profissional",
          professionalPhotoUrl: professional?.photoUrl ?? null,
          professionalCategory: professional?.category ?? null,
        };
      })
    );

    return { ...page, page: items };
  },
});

// ----------------------------------------------------------------------
// QUERY: posts de um profissional específico (para a página de perfil)
// ----------------------------------------------------------------------
export const listByProfessional = query({
  args: { professionalId: v.id("users") },
  handler: async (ctx, { professionalId }) => {
    const posts = await ctx.db
      .query("professionalPosts")
      .withIndex("by_professional", (q) => q.eq("professionalId", professionalId))
      .order("desc")
      .collect();

    return await Promise.all(
      posts.map(async (post) => ({
        ...post,
        mediaUrls: await Promise.all(
          post.mediaStorageIds.map((id) => ctx.storage.getUrl(id))
        ),
      }))
    );
  },
});

// ----------------------------------------------------------------------
// MUTATION: curtir / descurtir (toggle)
// ----------------------------------------------------------------------
export const toggleLike = mutation({
  args: { postId: v.id("professionalPosts"), userId: v.id("users") },
  handler: async (ctx, { postId, userId }) => {
    const existing = await ctx.db
      .query("professionalPostLikes")
      .withIndex("by_post_and_user", (q) => q.eq("postId", postId).eq("userId", userId))
      .unique();

    const post = await ctx.db.get(postId);
    if (!post) throw new Error("Post não encontrado");

    if (existing) {
      await ctx.db.delete(existing._id);
      await ctx.db.patch(postId, { likesCount: Math.max(0, post.likesCount - 1) });
      return { liked: false };
    } else {
      await ctx.db.insert("professionalPostLikes", { postId, userId, createdAt: Date.now() });
      await ctx.db.patch(postId, { likesCount: post.likesCount + 1 });
      return { liked: true };
    }
  },
});

// ----------------------------------------------------------------------
// MUTATION: comentar
// ----------------------------------------------------------------------
export const addComment = mutation({
  args: {
    postId: v.id("professionalPosts"),
    userId: v.id("users"),
    userName: v.string(),
    text: v.string(),
  },
  handler: async (ctx, args) => {
    const post = await ctx.db.get(args.postId);
    if (!post) throw new Error("Post não encontrado");

    const commentId = await ctx.db.insert("professionalPostComments", {
      ...args,
      createdAt: Date.now(),
    });
    await ctx.db.patch(args.postId, { commentsCount: post.commentsCount + 1 });
    return commentId;
  },
});

export const listComments = query({
  args: { postId: v.id("professionalPosts") },
  handler: async (ctx, { postId }) => {
    return await ctx.db
      .query("professionalPostComments")
      .withIndex("by_post", (q) => q.eq("postId", postId))
      .order("asc")
      .collect();
  },
});

// ----------------------------------------------------------------------
// STORIES (24h)
// ----------------------------------------------------------------------
export const createStory = mutation({
  args: {
    professionalId: v.id("users"),
    mediaStorageId: v.id("_storage"),
    mediaType: v.union(v.literal("foto"), v.literal("video")),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    return await ctx.db.insert("professionalStories", {
      ...args,
      createdAt: now,
      expiresAt: now + 24 * 60 * 60 * 1000,
    });
  },
});

export const listActiveStories = query({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const all = await ctx.db.query("professionalStories").withIndex("by_expiresAt").collect();
    const active = all.filter((s) => s.expiresAt > now);

    return await Promise.all(
      active.map(async (story) => {
        const professional = await ctx.db.get(story.professionalId);
        return {
          ...story,
          mediaUrl: await ctx.storage.getUrl(story.mediaStorageId),
          professionalName: professional?.name ?? "Profissional",
          professionalPhotoUrl: professional?.photoUrl ?? null,
        };
      })
    );
  },
});

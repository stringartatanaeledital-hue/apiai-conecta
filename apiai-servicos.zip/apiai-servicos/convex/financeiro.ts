// ============================================================================
// convex/financeiro.ts — Área Financeira — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const typeValidator = v.union(
  v.literal("receita"),
  v.literal("despesa"),
  v.literal("comissao"),
  v.literal("pix")
);

export const addTransaction = mutation({
  args: {
    ownerId: v.id("users"),
    type: typeValidator,
    amountCents: v.number(),
    description: v.string(),
    category: v.optional(v.string()),
    invoiceStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("financialTransactions", { ...args, createdAt: Date.now() });
  },
});

// Resumo financeiro: saldo, receita, despesas, comissões, Pix
export const getSummary = query({
  args: { ownerId: v.id("users"), sinceDays: v.optional(v.number()) },
  handler: async (ctx, { ownerId, sinceDays = 30 }) => {
    const since = Date.now() - sinceDays * 24 * 60 * 60 * 1000;
    const transactions = await ctx.db
      .query("financialTransactions")
      .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
      .collect();

    const recent = transactions.filter((t) => t.createdAt >= since);

    const totals = { receita: 0, despesa: 0, comissao: 0, pix: 0 };
    for (const t of recent) totals[t.type] += t.amountCents;

    const saldoCents = totals.receita + totals.pix - totals.despesa - totals.comissao;

    return { totals, saldoCents, transactionCount: recent.length };
  },
});

// Série diária de receita (para gráfico de linha, últimos N dias)
export const getRevenueTimeline = query({
  args: { ownerId: v.id("users"), days: v.optional(v.number()) },
  handler: async (ctx, { ownerId, days = 7 }) => {
    const since = Date.now() - days * 24 * 60 * 60 * 1000;
    const transactions = await ctx.db
      .query("financialTransactions")
      .withIndex("by_owner_and_type", (q) => q.eq("ownerId", ownerId).eq("type", "receita"))
      .collect();

    const byDay: Record<string, number> = {};
    for (const t of transactions.filter((t) => t.createdAt >= since)) {
      const day = new Date(t.createdAt).toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
      });
      byDay[day] = (byDay[day] ?? 0) + t.amountCents;
    }

    return Object.entries(byDay).map(([day, amountCents]) => ({ day, amountCents }));
  },
});

export const listTransactions = query({
  args: { ownerId: v.id("users"), type: v.optional(typeValidator) },
  handler: async (ctx, { ownerId, type }) => {
    const all = await ctx.db
      .query("financialTransactions")
      .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
      .order("desc")
      .collect();

    return type ? all.filter((t) => t.type === type) : all;
  },
});

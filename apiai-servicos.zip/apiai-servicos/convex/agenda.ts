// ============================================================================
// convex/agenda.ts — Agenda (calendário) — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

const typeValidator = v.union(v.literal("servico"), v.literal("compromisso"), v.literal("bloqueio"));

export const createEvent = mutation({
  args: {
    ownerId: v.id("users"),
    title: v.string(),
    description: v.optional(v.string()),
    startAt: v.number(),
    endAt: v.number(),
    type: typeValidator,
    relatedOrderId: v.optional(v.id("serviceOrders")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("agendaEvents", { ...args, createdAt: Date.now() });
  },
});

export const updateEvent = mutation({
  args: {
    eventId: v.id("agendaEvents"),
    title: v.optional(v.string()),
    startAt: v.optional(v.number()),
    endAt: v.optional(v.number()),
  },
  handler: async (ctx, { eventId, ...patch }) => {
    await ctx.db.patch(eventId, patch);
  },
});

export const deleteEvent = mutation({
  args: { eventId: v.id("agendaEvents") },
  handler: async (ctx, { eventId }) => {
    await ctx.db.delete(eventId);
  },
});

// Lista eventos dentro de um intervalo (para as visões dia/semana/mês)
export const listEventsInRange = query({
  args: { ownerId: v.id("users"), start: v.number(), end: v.number() },
  handler: async (ctx, { ownerId, start, end }) => {
    const events = await ctx.db
      .query("agendaEvents")
      .withIndex("by_owner_and_startAt", (q) =>
        q.eq("ownerId", ownerId).gte("startAt", start).lte("startAt", end)
      )
      .collect();
    return events;
  },
});

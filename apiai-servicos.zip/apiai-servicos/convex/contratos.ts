// ============================================================================
// convex/contratos.ts
// Backend do módulo Contratos (assinatura digital + QR Code) — ATAMURA SERVIÇOS Ω
// ============================================================================

import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// Gera um token aleatório simples para validação via QR Code.
// Em produção, troque por algo criptograficamente mais forte se necessário.
function generateToken(): string {
  return (
    Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
  ).toUpperCase();
}

export const createContract = mutation({
  args: {
    orderId: v.id("serviceOrders"),
    clientId: v.id("users"),
    professionalId: v.id("users"),
    warrantyMonths: v.optional(v.number()),
    pdfStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("contracts", {
      ...args,
      qrCodeToken: generateToken(),
      signedByClient: false,
      signedByProfessional: false,
      status: "aguardando_assinatura",
      createdAt: Date.now(),
    });
  },
});

export const getContract = query({
  args: { contractId: v.id("contracts") },
  handler: async (ctx, { contractId }) => {
    const contract = await ctx.db.get(contractId);
    if (!contract) return null;
    const pdfUrl = contract.pdfStorageId
      ? await ctx.storage.getUrl(contract.pdfStorageId)
      : null;
    return { ...contract, pdfUrl };
  },
});

// Usado pelo app quando alguém escaneia o QR Code do contrato para validar
export const getContractByToken = query({
  args: { qrCodeToken: v.string() },
  handler: async (ctx, { qrCodeToken }) => {
    return await ctx.db
      .query("contracts")
      .withIndex("by_qrCodeToken", (q) => q.eq("qrCodeToken", qrCodeToken))
      .unique();
  },
});

export const listByClient = query({
  args: { clientId: v.id("users") },
  handler: async (ctx, { clientId }) => {
    return await ctx.db
      .query("contracts")
      .withIndex("by_client", (q) => q.eq("clientId", clientId))
      .order("desc")
      .collect();
  },
});

export const listByProfessional = query({
  args: { professionalId: v.id("users") },
  handler: async (ctx, { professionalId }) => {
    return await ctx.db
      .query("contracts")
      .withIndex("by_professional", (q) => q.eq("professionalId", professionalId))
      .order("desc")
      .collect();
  },
});

// Assinatura digital: marca o lado do cliente ou do profissional. Quando
// ambos assinam, o contrato passa a "assinado" automaticamente.
export const signContract = mutation({
  args: {
    contractId: v.id("contracts"),
    signer: v.union(v.literal("cliente"), v.literal("profissional")),
  },
  handler: async (ctx, { contractId, signer }) => {
    const contract = await ctx.db.get(contractId);
    if (!contract) throw new Error("Contrato não encontrado");

    const now = Date.now();
    const patch: Record<string, unknown> =
      signer === "cliente"
        ? { signedByClient: true, signedByClientAt: now }
        : { signedByProfessional: true, signedByProfessionalAt: now };

    const bothSigned =
      signer === "cliente"
        ? contract.signedByProfessional
        : contract.signedByClient;

    if (bothSigned) patch.status = "assinado";

    await ctx.db.patch(contractId, patch);
    return { status: bothSigned ? "assinado" : "aguardando_assinatura" };
  },
});

export const cancelContract = mutation({
  args: { contractId: v.id("contracts") },
  handler: async (ctx, { contractId }) => {
    await ctx.db.patch(contractId, { status: "cancelado" });
  },
});

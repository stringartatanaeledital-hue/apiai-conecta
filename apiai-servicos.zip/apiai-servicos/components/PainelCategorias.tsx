"use client";

// ============================================================================
// components/PainelCategorias.tsx — Apiaí Serviços
// Adicione profissões extras sem mexer em código, direto pelo painel admin.
// ============================================================================

import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { DEPARTAMENTOS } from "@/lib/categoriasProfissoes";
import { Plus, X } from "lucide-react";

export default function PainelCategorias({ adminUserId }: { adminUserId?: Id<"users"> }) {
  const [departmentKey, setDepartmentKey] = useState(DEPARTAMENTOS[0].key);
  const [profession, setProfession] = useState("");

  const customCategories = useQuery(api.adminCategoriasClientes.listCustomCategories, {});
  const addCategory = useMutation(api.adminCategoriasClientes.addCustomCategory);
  const removeCategory = useMutation(api.adminCategoriasClientes.removeCustomCategory);

  async function handleAdd() {
    if (!profession.trim()) return;
    await addCategory({ departmentKey, profession: profession.trim(), addedBy: adminUserId });
    setProfession("");
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <p className="text-white text-sm font-medium mb-1">Categorias e profissões</p>
      <p className="text-zinc-500 text-xs mb-4">
        Adicione novas profissões aos departamentos existentes, sem precisar mexer em código.
      </p>

      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <select
          value={departmentKey}
          onChange={(e) => setDepartmentKey(e.target.value)}
          className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white outline-none"
        >
          {DEPARTAMENTOS.map((d) => (
            <option key={d.key} value={d.key}>
              {d.label}
            </option>
          ))}
        </select>
        <input
          value={profession}
          onChange={(e) => setProfession(e.target.value)}
          placeholder="Nova profissão (ex: Instalador de piso vinílico)"
          className="flex-1 bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
        />
        <button
          onClick={handleAdd}
          className="flex items-center justify-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-amber-500 text-black"
        >
          <Plus size={15} /> Adicionar
        </button>
      </div>

      <div className="space-y-4">
        {DEPARTAMENTOS.map((dept) => {
          const extras = customCategories?.filter((c) => c.departmentKey === dept.key) ?? [];
          if (extras.length === 0) return null;
          return (
            <div key={dept.key}>
              <p className="text-zinc-500 text-xs mb-1.5">{dept.label} — profissões adicionadas</p>
              <div className="flex flex-wrap gap-1.5">
                {extras.map((extra) => (
                  <span
                    key={extra._id}
                    className="flex items-center gap-1.5 text-xs text-zinc-300 bg-zinc-800 px-2.5 py-1 rounded-md"
                  >
                    {extra.profession}
                    <button
                      onClick={() => removeCategory({ categoryId: extra._id })}
                      className="text-zinc-500 hover:text-red-400"
                    >
                      <X size={11} />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

"use client";

// ============================================================================
// components/TopBar.tsx — Barra Superior Inteligente — ATAMURA SERVIÇOS Ω
// Busca por voz (Web Speech API do navegador, sem backend de IA), clima e
// localização atual. (Busca por foto e "Pergunte à IA" ficam de fora por
// dependerem de IA, conforme combinado.)
// ============================================================================

import { useState, useRef, useEffect } from "react";
import { Search, Mic, Bell, MessageCircle, Calendar, Wallet, Moon, Sun, MapPin } from "lucide-react";

// Tipagem mínima para a Web Speech API (nem todo TS lib inclui por padrão)
type SpeechRecognitionResult = { transcript: string };
interface MinimalSpeechRecognition extends EventTarget {
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: ((event: any) => void) | null;
  onend: (() => void) | null;
}

function useVoiceSearch(onResult: (text: string) => void) {
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<MinimalSpeechRecognition | null>(null);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition: MinimalSpeechRecognition = new SpeechRecognition();
    recognition.lang = "pt-BR";
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      onResult(transcript);
      setListening(false);
    };
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
  }, [onResult]);

  function toggleListening() {
    if (!recognitionRef.current) {
      alert("Busca por voz não é suportada neste navegador.");
      return;
    }
    if (listening) {
      recognitionRef.current.stop();
      setListening(false);
    } else {
      recognitionRef.current.start();
      setListening(true);
    }
  }

  return { listening, toggleListening };
}

export default function TopBar({
  onSearch,
  cityLabel,
  weather,
  notificationsCount = 0,
  messagesCount = 0,
  userName,
  userRole,
  userPhotoUrl,
  onToggleTheme,
  isDark = true,
}: {
  onSearch: (query: string) => void;
  cityLabel: string;
  weather?: { tempC: number; condition: string } | null;
  notificationsCount?: number;
  messagesCount?: number;
  userName: string;
  userRole: string;
  userPhotoUrl?: string | null;
  onToggleTheme?: () => void;
  isDark?: boolean;
}) {
  const [query, setQuery] = useState("");
  const { listening, toggleListening } = useVoiceSearch((text) => {
    setQuery(text);
    onSearch(text);
  });

  return (
    <div className="flex items-center gap-4 px-6 py-4 border-b border-zinc-800 bg-zinc-950">
      {/* Busca */}
      <div className="flex-1 max-w-xl relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && onSearch(query)}
          placeholder="O que você precisa hoje?"
          className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-9 pr-10 py-2.5 text-sm text-white placeholder:text-zinc-500 outline-none focus:border-amber-500/50"
        />
        <button
          onClick={toggleListening}
          className={`absolute right-2 top-1/2 -translate-y-1/2 ${
            listening ? "text-red-400 animate-pulse" : "text-zinc-500 hover:text-amber-400"
          }`}
          aria-label="Busca por voz"
        >
          <Mic size={16} />
        </button>
      </div>

      {/* Localização (CEP / cidade atual) */}
      <div className="hidden md:flex items-center gap-1.5 text-zinc-400 text-sm whitespace-nowrap">
        <MapPin size={14} />
        {cityLabel}
      </div>

      {/* Clima */}
      {weather && (
        <div className="hidden lg:flex items-center gap-1.5 text-zinc-400 text-sm whitespace-nowrap">
          <Sun size={14} className="text-amber-400" />
          {weather.tempC}°C · {weather.condition}
        </div>
      )}

      {/* Ícones de ação */}
      <div className="flex items-center gap-4">
        <IconWithBadge icon={Bell} count={notificationsCount} />
        <IconWithBadge icon={MessageCircle} count={messagesCount} />
        <Calendar size={18} className="text-zinc-400" />
        <Wallet size={18} className="text-zinc-400" />
        <button onClick={onToggleTheme} aria-label="Alternar tema">
          {isDark ? (
            <Moon size={18} className="text-zinc-400" />
          ) : (
            <Sun size={18} className="text-amber-400" />
          )}
        </button>
      </div>

      {/* Usuário */}
      <div className="flex items-center gap-2 pl-4 border-l border-zinc-800">
        {userPhotoUrl ? (
          <img src={userPhotoUrl} alt={userName} className="w-8 h-8 rounded-full object-cover" />
        ) : (
          <div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-black text-xs font-semibold">
            {userName.slice(0, 2).toUpperCase()}
          </div>
        )}
        <div className="hidden sm:block">
          <p className="text-white text-xs font-medium leading-tight">{userName}</p>
          <p className="text-zinc-500 text-[10px] leading-tight">{userRole}</p>
        </div>
      </div>
    </div>
  );
}

function IconWithBadge({ icon: Icon, count }: { icon: any; count: number }) {
  return (
    <div className="relative">
      <Icon size={18} className="text-zinc-400" />
      {count > 0 && (
        <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-black text-[9px] font-semibold rounded-full min-w-[15px] h-[15px] flex items-center justify-center px-0.5">
          {count}
        </span>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------
// Exemplo de uso — clima via API pública (sem IA), ex: Open-Meteo
// (chame isso num Server Component ou API route e passe como prop `weather`)
//
// const res = await fetch(
//   `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`
// );
// const data = await res.json();
// const weather = { tempC: data.current_weather.temperature, condition: "Ensolarado" };
// ----------------------------------------------------------------------

"use client";

// ============================================================================
// components/ServiceTimeline.tsx
// Linha do tempo visual do serviço — ATAMURA SERVIÇOS Ω
// Solicitado → Orçamento → Aceito → Em execução → Concluído → Avaliação
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import {
  Check,
  FileText,
  ThumbsUp,
  Hammer,
  Flag,
  Star,
} from "lucide-react";

const STEPS = [
  { key: "solicitado", label: "Solicitado", icon: FileText },
  { key: "orcamento", label: "Orçamento", icon: FileText },
  { key: "aceito", label: "Aceito", icon: ThumbsUp },
  { key: "em_execucao", label: "Em execução", icon: Hammer },
  { key: "concluido", label: "Concluído", icon: Flag },
  { key: "avaliacao", label: "Avaliação", icon: Star },
] as const;

function formatDateTime(ts: number) {
  return new Date(ts).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function ServiceTimeline({ orderId }: { orderId: Id<"serviceOrders"> }) {
  const data = useQuery(api.serviceTimeline.getTimelineByOrder, { orderId });

  if (data === undefined) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 animate-pulse">
        <div className="h-4 w-40 bg-zinc-800 rounded mb-4" />
        <div className="h-24 bg-zinc-800 rounded" />
      </div>
    );
  }

  const currentIndex = STEPS.findIndex((s) => s.key === data.currentStatus);

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6">
      <h3 className="text-white font-semibold mb-6">Linha do tempo do serviço</h3>

      {/* Stepper horizontal */}
      <div className="flex items-center mb-8">
        {STEPS.map((step, i) => {
          const Icon = step.icon;
          const done = i <= currentIndex;
          const isLast = i === STEPS.length - 1;
          return (
            <div key={step.key} className="flex items-center flex-1 last:flex-none">
              <div className="flex flex-col items-center gap-2">
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-colors ${
                    done
                      ? "bg-amber-500 border-amber-500 text-black"
                      : "bg-zinc-800 border-zinc-700 text-zinc-500"
                  }`}
                >
                  {done ? <Check size={16} /> : <Icon size={16} />}
                </div>
                <span
                  className={`text-xs whitespace-nowrap ${
                    done ? "text-amber-400 font-medium" : "text-zinc-500"
                  }`}
                >
                  {step.label}
                </span>
              </div>
              {!isLast && (
                <div
                  className={`flex-1 h-0.5 mx-2 ${
                    i < currentIndex ? "bg-amber-500" : "bg-zinc-800"
                  }`}
                />
              )}
            </div>
          );
        })}
      </div>

      {/* Histórico de eventos */}
      <div className="space-y-4">
        {data.events.length === 0 && (
          <p className="text-zinc-500 text-sm">Nenhum evento registrado ainda.</p>
        )}
        {data.events.map((event) => (
          <div key={event._id} className="flex gap-3 border-l-2 border-zinc-800 pl-4 relative">
            <div className="absolute -left-[5px] top-1 w-2 h-2 rounded-full bg-amber-500" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-white text-sm font-medium">{event.title}</p>
                <span className="text-zinc-500 text-xs">{formatDateTime(event.createdAt)}</span>
              </div>
              {event.description && (
                <p className="text-zinc-400 text-sm mt-0.5">{event.description}</p>
              )}
              {event.actorName && (
                <p className="text-zinc-600 text-xs mt-0.5">
                  {event.actorRole === "profissional" ? "Profissional: " : "Cliente: "}
                  {event.actorName}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// EXEMPLO DE USO (avançar status a partir de uma tela do profissional):
//
// const addEvent = useMutation(api.serviceTimeline.addTimelineEvent);
//
// await addEvent({
//   orderId,
//   status: "em_execucao",
//   title: "Serviço iniciado",
//   description: "Profissional chegou ao local às 08:00",
//   actorId: currentUserId,
//   actorName: "João Silva",
//   actorRole: "profissional",
// });
// ----------------------------------------------------------------------

"use client";

// ============================================================================
// components/PerfilProfissional.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { PlayCircle, FileBadge, MapPin, Award } from "lucide-react";
import { BadgesRow } from "./Gamificacao";

export default function PerfilProfissional({
  professionalId,
}: {
  professionalId: Id<"users">;
}) {
  const data = useQuery(api.portfolio.getPortfolio, { professionalId });

  if (data === undefined) {
    return <div className="h-64 rounded-xl bg-zinc-900/60 border border-zinc-800 animate-pulse" />;
  }
  if (!data?.professional) return null;

  const { professional, portfolio } = data;

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
      {/* Foto de capa / vídeo institucional */}
      <div className="aspect-video bg-zinc-800 relative flex items-center justify-center">
        {portfolio?.videoUrl ? (
          <video src={portfolio.videoUrl} controls className="w-full h-full object-cover" />
        ) : (
          <img
            src={(professional as any).photoUrl ?? "/avatar-placeholder.png"}
            alt={(professional as any).name}
            className="w-full h-full object-cover"
          />
        )}
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="text-white text-lg font-semibold">{(professional as any).name}</p>
            <p className="text-zinc-500 text-sm">{(professional as any).category}</p>
          </div>
          {portfolio?.yearsExperience !== undefined && (
            <span className="text-xs text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-md">
              {portfolio.yearsExperience} anos de experiência
            </span>
          )}
        </div>

        <BadgesRow professionalId={professionalId} />

        {portfolio?.bio && <p className="text-zinc-300 text-sm mt-4">{portfolio.bio}</p>}

        {portfolio?.specialties && portfolio.specialties.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {portfolio.specialties.map((s) => (
              <span key={s} className="text-xs text-zinc-300 bg-zinc-800 px-2.5 py-1 rounded-md">
                {s}
              </span>
            ))}
          </div>
        )}

        {/* Portfólio de fotos */}
        {portfolio?.portfolioImageUrls && portfolio.portfolioImageUrls.length > 0 && (
          <div className="mt-4">
            <p className="text-zinc-400 text-xs mb-2">Portfólio</p>
            <div className="grid grid-cols-4 gap-1.5">
              {portfolio.portfolioImageUrls.map((url, i) => (
                <img
                  key={i}
                  src={url ?? undefined}
                  className="w-full aspect-square object-cover rounded-lg"
                  alt={`Trabalho ${i + 1}`}
                />
              ))}
            </div>
          </div>
        )}

        {/* Certificados */}
        {portfolio?.certificateUrls && portfolio.certificateUrls.length > 0 && (
          <div className="mt-4">
            <p className="text-zinc-400 text-xs mb-2">Certificados</p>
            <div className="flex flex-wrap gap-2">
              {portfolio.certificateUrls.map((c, i) => (
                <a
                  key={i}
                  href={c.url ?? undefined}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs text-amber-400 bg-amber-500/10 px-2.5 py-1.5 rounded-md"
                >
                  <FileBadge size={12} /> {c.name}
                </a>
              ))}
            </div>
          </div>
        )}

        {portfolio?.droneUrl && (
          <a
            href={portfolio.droneUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-zinc-400 mt-4"
          >
            <PlayCircle size={14} /> Ver imagens aéreas (drone)
          </a>
        )}
      </div>
    </div>
  );
}

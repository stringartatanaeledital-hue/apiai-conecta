"use client";

// ============================================================================
// components/EnviarConvite.tsx — Apiaí Serviços
// Você escolhe a pessoa e decide na hora: ela vai usar de graça (ex: um
// amigo seu) ou vai pagar normalmente. Sem espera, sem aprovação depois.
// ============================================================================

import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Search, Gift, CreditCard, Send } from "lucide-react";

export default function EnviarConvite({ adminUserId }: { adminUserId?: Id<"users"> }) {
  const [search, setSearch] = useState("");
  const [selectedUserId, setSelectedUserId] = useState<Id<"users"> | null>(null);
  const [modoAcesso, setModoAcesso] = useState<"gratuito" | "pago">("gratuito");
  const [feedback, setFeedback] = useState<string | null>(null);

  const users = useQuery(api.enviarConvite.listUsersForInvite, { searchText: search || undefined });
  const enviar = useMutation(api.enviarConvite.enviarConviteDireto);

  const selectedUser = users?.find((u) => u._id === selectedUserId);

  async function handleEnviar() {
    if (!selectedUserId) return;
    const result = await enviar({
      userId: selectedUserId,
      modoAcesso,
      sentBy: adminUserId,
    });
    setFeedback(
      result.modoAcesso === "gratuito"
        ? `${selectedUser?.name} agora tem acesso gratuito.`
        : `${selectedUser?.name} vai seguir com o plano pago normal.`
    );
    setSelectedUserId(null);
    setSearch("");
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <p className="text-white text-sm font-medium mb-1">Enviar convite</p>
      <p className="text-zinc-500 text-xs mb-4">
        Escolha quem vai receber e decida na hora: grátis (ex: um amigo) ou pago.
      </p>

      <div className="relative mb-3">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por nome ou e-mail"
          className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
        />
      </div>

      {!selectedUserId && (
        <div className="max-h-40 overflow-y-auto space-y-1 mb-3">
          {users?.map((u) => (
            <button
              key={u._id}
              onClick={() => setSelectedUserId(u._id)}
              className="w-full flex items-center justify-between text-left px-3 py-2 rounded-lg hover:bg-zinc-800 text-sm"
            >
              <span className="text-white">{u.name}</span>
              <span className="text-zinc-500 text-xs">{u.email}</span>
            </button>
          ))}
        </div>
      )}

      {selectedUserId && (
        <>
          <div className="flex items-center justify-between bg-zinc-800/60 rounded-lg px-3 py-2 mb-4">
            <span className="text-white text-sm">{selectedUser?.name}</span>
            <button
              onClick={() => setSelectedUserId(null)}
              className="text-zinc-500 text-xs hover:text-white"
            >
              trocar
            </button>
          </div>

          <p className="text-zinc-400 text-xs mb-2">Modo de acesso</p>
          <div className="grid grid-cols-2 gap-2 mb-4">
            <button
              onClick={() => setModoAcesso("gratuito")}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border transition-colors ${
                modoAcesso === "gratuito"
                  ? "border-amber-500 bg-amber-500/10 text-amber-400"
                  : "border-zinc-800 text-zinc-400"
              }`}
            >
              <Gift size={18} />
              <span className="text-xs font-medium">Grátis</span>
              <span className="text-[10px] opacity-70">Ex: um amigo</span>
            </button>
            <button
              onClick={() => setModoAcesso("pago")}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border transition-colors ${
                modoAcesso === "pago"
                  ? "border-amber-500 bg-amber-500/10 text-amber-400"
                  : "border-zinc-800 text-zinc-400"
              }`}
            >
              <CreditCard size={18} />
              <span className="text-xs font-medium">Pago</span>
              <span className="text-[10px] opacity-70">Plano normal</span>
            </button>
          </div>

          <button
            onClick={handleEnviar}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium"
          >
            <Send size={15} /> Confirmar convite
          </button>
        </>
      )}

      {feedback && <p className="text-zinc-400 text-xs mt-3">{feedback}</p>}
    </div>
  );
}

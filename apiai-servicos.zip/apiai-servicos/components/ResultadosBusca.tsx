"use client";

// ============================================================================
// components/ResultadosBusca.tsx — Apiaí Serviços
// Tela de resultados ligada à busca do TopBar — busca profissionais pelo
// texto digitado (nome, categoria ou profissão).
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Star } from "lucide-react";

export default function ResultadosBusca({ query }: { query: string }) {
  const professionals = useQuery(
    api.profissionaisBusca.searchProfessionals,
    query ? { searchText: query } : "skip"
  );

  if (!query) {
    return <p className="text-zinc-500 text-sm">Digite algo na busca para ver resultados.</p>;
  }

  return (
    <div>
      <p className="text-zinc-400 text-sm mb-4">
        Resultados para <span className="text-white font-medium">"{query}"</span>
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {professionals?.map((p: any) => (
          <div key={p._id} className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
            <div className="aspect-square bg-zinc-800">
              {p.photoUrl && <img src={p.photoUrl} alt={p.name} className="w-full h-full object-cover" />}
            </div>
            <div className="p-3">
              <p className="text-white text-sm font-medium truncate">{p.name}</p>
              <p className="text-zinc-500 text-xs">{p.subcategory}</p>
              <span className="flex items-center gap-1 text-amber-400 text-xs mt-1">
                <Star size={11} className="fill-amber-400" /> {p.rating ?? "—"}
              </span>
            </div>
          </div>
        ))}
      </div>

      {professionals?.length === 0 && (
        <p className="text-zinc-500 text-sm">Nenhum resultado encontrado para essa busca.</p>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------
// LIGAÇÃO COM O TOPBAR — no seu AppShell/página principal:
//
// const [searchQuery, setSearchQuery] = useState("");
//
// <TopBar onSearch={setSearchQuery} ... />
// {searchQuery && <ResultadosBusca query={searchQuery} />}
// ----------------------------------------------------------------------

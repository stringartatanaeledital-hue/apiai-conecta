"use client";

// ============================================================================
// components/CadastroProfissional.tsx — Apiaí Serviços
// Formulário de cadastro/edição de categoria e profissão do profissional,
// usando a mesma taxonomia da tela do cliente (lib/categoriasProfissoes.ts).
// ============================================================================

import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { DEPARTAMENTOS } from "@/lib/categoriasProfissoes";
import { Check } from "lucide-react";

export default function CadastroProfissional({
  professionalId,
  onSaved,
}: {
  professionalId: Id<"users">;
  onSaved?: () => void;
}) {
  const [category, setCategory] = useState<string | null>(null);
  const [subcategory, setSubcategory] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Ajuste esta mutation conforme os campos reais da sua tabela "users"
  const updateProfessional = useMutation(api.profissionaisBusca.updateCategory);

  const departamentoSelecionado = DEPARTAMENTOS.find((d) => d.key === category);

  async function handleSave() {
    if (!category || !subcategory) return;
    setSaving(true);
    try {
      await updateProfessional({ professionalId, category, subcategory });
      onSaved?.();
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <p className="text-white text-sm font-medium mb-1">Área de atuação</p>
      <p className="text-zinc-500 text-xs mb-4">
        Escolha o departamento e a profissão que melhor descrevem seu trabalho
      </p>

      <p className="text-zinc-400 text-xs mb-2">Departamento</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
        {DEPARTAMENTOS.map((dept) => (
          <button
            key={dept.key}
            onClick={() => {
              setCategory(dept.key);
              setSubcategory(null);
            }}
            className={`text-xs text-left px-3 py-2 rounded-lg border transition-colors ${
              category === dept.key
                ? "border-amber-500 bg-amber-500/10 text-amber-400"
                : "border-zinc-800 text-zinc-300 hover:border-zinc-700"
            }`}
          >
            {dept.label}
          </button>
        ))}
      </div>

      {departamentoSelecionado && (
        <>
          <p className="text-zinc-400 text-xs mb-2">Profissão</p>
          <div className="flex flex-wrap gap-2 mb-5">
            {departamentoSelecionado.profissoes.map((prof) => (
              <button
                key={prof}
                onClick={() => setSubcategory(prof)}
                className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border transition-colors ${
                  subcategory === prof
                    ? "border-amber-500 bg-amber-500 text-black font-medium"
                    : "border-zinc-800 text-zinc-300 hover:border-zinc-700"
                }`}
              >
                {subcategory === prof && <Check size={12} />}
                {prof}
              </button>
            ))}
          </div>
        </>
      )}

      <button
        onClick={handleSave}
        disabled={!category || !subcategory || saving}
        className="w-full py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium disabled:bg-zinc-800 disabled:text-zinc-600"
      >
        {saving ? "Salvando..." : "Salvar área de atuação"}
      </button>
    </div>
  );
}

"use client";

// ============================================================================
// components/Agenda.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { ChevronLeft, ChevronRight } from "lucide-react";

const TYPE_COLOR: Record<string, string> = {
  servico: "bg-amber-500",
  compromisso: "bg-blue-500",
  bloqueio: "bg-zinc-600",
};

function startOfWeek(date: Date) {
  const d = new Date(date);
  d.setDate(d.getDate() - d.getDay());
  d.setHours(0, 0, 0, 0);
  return d;
}

export default function Agenda({ ownerId }: { ownerId: Id<"users"> }) {
  const [view, setView] = useState<"dia" | "semana" | "mes">("semana");
  const [anchor, setAnchor] = useState(new Date());

  const weekStart = startOfWeek(anchor);
  const rangeStart = weekStart.getTime();
  const rangeEnd = weekStart.getTime() + 7 * 24 * 60 * 60 * 1000;

  const events = useQuery(api.agenda.listEventsInRange, {
    ownerId,
    start: rangeStart,
    end: rangeEnd,
  });

  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    return d;
  });

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const d = new Date(anchor);
              d.setDate(d.getDate() - 7);
              setAnchor(d);
            }}
            className="text-zinc-400 hover:text-white"
          >
            <ChevronLeft size={18} />
          </button>
          <p className="text-white text-sm font-medium">
            {weekStart.toLocaleDateString("pt-BR", { day: "2-digit", month: "long" })}
          </p>
          <button
            onClick={() => {
              const d = new Date(anchor);
              d.setDate(d.getDate() + 7);
              setAnchor(d);
            }}
            className="text-zinc-400 hover:text-white"
          >
            <ChevronRight size={18} />
          </button>
        </div>
        <div className="flex gap-1 bg-zinc-800 rounded-lg p-1">
          {(["dia", "semana", "mes"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`text-xs px-3 py-1 rounded-md capitalize ${
                view === v ? "bg-amber-500 text-black" : "text-zinc-400"
              }`}
            >
              {v}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {days.map((d) => {
          const dayEvents =
            events?.filter((e) => new Date(e.startAt).toDateString() === d.toDateString()) ?? [];
          return (
            <div key={d.toISOString()} className="min-h-[100px]">
              <p className="text-zinc-500 text-xs text-center mb-2">
                {d.toLocaleDateString("pt-BR", { weekday: "short" })}
                <br />
                <span className="text-white text-sm">{d.getDate()}</span>
              </p>
              <div className="space-y-1">
                {dayEvents.map((e) => (
                  <div
                    key={e._id}
                    className={`text-[10px] text-white px-1.5 py-1 rounded truncate ${
                      TYPE_COLOR[e.type]
                    }`}
                    title={e.title}
                  >
                    {e.title}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

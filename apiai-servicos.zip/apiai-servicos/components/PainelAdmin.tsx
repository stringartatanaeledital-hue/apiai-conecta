"use client";

// ============================================================================
// components/PainelAdmin.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Users, ClipboardList, DollarSign, Ticket, Megaphone } from "lucide-react";

function formatBRL(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function PainelAdmin() {
  const summary = useQuery(api.admin.getPlatformSummary);
  const coupons = useQuery(api.admin.listCoupons);
  const campaigns = useQuery(api.admin.listActiveCampaigns);

  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <StatCard icon={ClipboardList} label="Ordens abertas" value={summary?.ordensAbertas ?? 0} />
        <StatCard icon={Users} label="Profissionais" value={summary?.totalProfissionais ?? 0} />
        <StatCard
          icon={DollarSign}
          label="Receita total"
          value={formatBRL(summary?.receitaTotalCents ?? 0)}
          highlight
        />
        <StatCard icon={Megaphone} label="Campanhas ativas" value={summary?.campanhasAtivas ?? 0} />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Ticket size={16} className="text-amber-400" />
            <p className="text-white text-sm font-medium">Cupons</p>
          </div>
          <div className="space-y-2">
            {coupons?.slice(0, 5).map((c) => (
              <div key={c._id} className="flex items-center justify-between text-sm">
                <span className="text-white font-mono">{c.code}</span>
                <span className="text-zinc-400">
                  {c.discountPercent}% · {c.usedCount}/{c.usageLimit}
                </span>
              </div>
            ))}
            {coupons?.length === 0 && <p className="text-zinc-500 text-sm">Nenhum cupom criado.</p>}
          </div>
        </div>

        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Megaphone size={16} className="text-amber-400" />
            <p className="text-white text-sm font-medium">Campanhas ativas</p>
          </div>
          <div className="space-y-2">
            {campaigns?.map((c) => (
              <div key={c._id} className="text-sm">
                <p className="text-white">{c.title}</p>
                <p className="text-zinc-500 text-xs capitalize">{c.targetAudience}</p>
              </div>
            ))}
            {campaigns?.length === 0 && <p className="text-zinc-500 text-sm">Nenhuma campanha ativa.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  highlight,
}: {
  icon: any;
  label: string;
  value: string | number;
  highlight?: boolean;
}) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
      <Icon size={16} className={highlight ? "text-amber-400" : "text-zinc-500"} />
      <p className={`text-sm font-semibold mt-2 ${highlight ? "text-amber-400" : "text-white"}`}>
        {value}
      </p>
      <p className="text-zinc-500 text-xs">{label}</p>
    </div>
  );
}

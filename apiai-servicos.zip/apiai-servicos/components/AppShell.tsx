"use client";

// ============================================================================
// components/AppShell.tsx — Shell principal do ATAMURA SERVIÇOS Ω
// Sidebar de navegação amarrando todos os módulos construídos + TopBar.
// Esse é o "programa completo": troque o conteúdo central conforme a rota
// ativa (use seu router — Next.js App Router, por exemplo).
// ============================================================================

import { useState, ReactNode } from "react";
import TopBar from "./TopBar";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Grid3x3,
  MapPin,
  Calendar,
  FileText,
  MessageCircle,
  CreditCard,
  BarChart3,
  ClipboardList,
  Building2,
  ShoppingBag,
  Star,
  Settings,
  UserCog,
  GraduationCap,
  Award,
  Gem,
  Siren,
  HardHat,
} from "lucide-react";

const NAV_ITEMS = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "clientes", label: "Clientes", icon: Users },
  { key: "profissionais", label: "Profissionais", icon: Briefcase },
  { key: "categorias", label: "Categorias", icon: Grid3x3 },
  { key: "seguranca", label: "Segurança do trabalho", icon: HardHat },
  { key: "mapa", label: "Mapa inteligente", icon: MapPin },
  { key: "agenda", label: "Agenda", icon: Calendar },
  { key: "orcamentos", label: "Orçamentos", icon: FileText },
  { key: "contratos", label: "Contratos", icon: FileText },
  { key: "mensagens", label: "Mensagens", icon: MessageCircle },
  { key: "pagamentos", label: "Pagamentos", icon: CreditCard },
  { key: "financeiro", label: "Financeiro", icon: BarChart3 },
  { key: "relatorios", label: "Relatórios", icon: ClipboardList },
  { key: "empresas", label: "Empresas", icon: Building2 },
  { key: "marketplace", label: "Marketplace", icon: ShoppingBag },
  { key: "cursos", label: "Cursos", icon: GraduationCap },
  { key: "gamificacao", label: "Gamificação", icon: Award },
  { key: "fidelidade", label: "Fidelidade", icon: Gem },
  { key: "emergencia", label: "Emergência 24h", icon: Siren },
  { key: "avaliacoes", label: "Avaliações", icon: Star },
  { key: "admin", label: "Administrativo", icon: UserCog },
  { key: "configuracoes", label: "Configurações", icon: Settings },
] as const;

export type NavKey = (typeof NAV_ITEMS)[number]["key"];

export default function AppShell({
  activeKey,
  onNavigate,
  children,
  userName,
  userRole,
  userPhotoUrl,
  cityLabel = "Apiaí - SP",
}: {
  activeKey: NavKey;
  onNavigate: (key: NavKey) => void;
  children: ReactNode;
  userName: string;
  userRole: string;
  userPhotoUrl?: string | null;
  cityLabel?: string;
}) {
  const [isDark, setIsDark] = useState(true);

  return (
    <div className="flex h-screen bg-black">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 border-r border-zinc-800 flex flex-col overflow-y-auto">
        <div className="flex items-center gap-2 px-5 py-5">
          <div className="w-9 h-9 rounded-lg bg-amber-500 flex items-center justify-center font-bold text-black">
            A
          </div>
          <div>
            <p className="text-white text-sm font-semibold leading-tight">APIAÍ</p>
            <p className="text-zinc-500 text-[10px] leading-tight">SERVIÇOS</p>
          </div>
        </div>

        <nav className="flex-1 px-3 space-y-0.5">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = item.key === activeKey;
            return (
              <button
                key={item.key}
                onClick={() => onNavigate(item.key)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  active
                    ? "bg-amber-500/10 text-amber-400 border-l-2 border-amber-500"
                    : "text-zinc-400 hover:bg-zinc-900 hover:text-white"
                }`}
              >
                <Icon size={17} />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="p-4 m-3 rounded-xl bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/20">
          <p className="text-white text-xs font-medium">Apiaí Serviços</p>
          <p className="text-zinc-500 text-[10px] mt-1">Tudo o que você precisa, aqui na região!</p>
        </div>
      </aside>

      {/* Conteúdo principal */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar
          onSearch={(q) => console.log("busca:", q)}
          cityLabel={cityLabel}
          weather={{ tempC: 22, condition: "Ensolarado" }}
          notificationsCount={3}
          messagesCount={8}
          userName={userName}
          userRole={userRole}
          userPhotoUrl={userPhotoUrl}
          isDark={isDark}
          onToggleTheme={() => setIsDark((v) => !v)}
        />
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// EXEMPLO DE USO (app/layout ou uma página principal):
//
// const [activeKey, setActiveKey] = useState<NavKey>("dashboard");
//
// <AppShell
//   activeKey={activeKey}
//   onNavigate={setActiveKey}
//   userName="Atanael Slompo"
//   userRole="Administrador"
// >
//   {activeKey === "financeiro" && <Financeiro ownerId={userId} />}
//   {activeKey === "marketplace" && <Marketplace buyerId={userId} />}
//   {activeKey === "agenda" && <Agenda ownerId={userId} />}
//   {activeKey === "cursos" && <Cursos userId={userId} />}
//   {activeKey === "emergencia" && <CentralEmergencia />}
//   {activeKey === "mapa" && <MapaInteligente />}
//   {activeKey === "admin" && <PainelAdmin />}
//   {/* ...demais módulos */}
// </AppShell>
// ----------------------------------------------------------------------

"use client";

// ============================================================================
// components/CadastroUsuario.tsx — Apiaí Serviços
// Tela de cadastro (cliente, profissional ou empresa).
// O hash da senha deve ser feito ANTES de chamar registerUser — nunca
// mande senha crua pro backend. Exemplo com bcryptjs no comentário no fim.
// ============================================================================

import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { User, Briefcase, Building2, Mail, Phone, Lock, Loader2 } from "lucide-react";

type Role = "cliente" | "profissional" | "empresa";

export default function CadastroUsuario({
  onRegistered,
}: {
  onRegistered?: (userId: string) => void;
}) {
  const registerUser = useMutation(api.auth.registerUser);

  const [role, setRole] = useState<Role>("cliente");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!name.trim() || !email.trim() || password.length < 6) {
      setError("Preencha nome, e-mail e uma senha com pelo menos 6 caracteres.");
      return;
    }

    setLoading(true);
    try {
      // ATENÇÃO: em produção, gere o hash da senha numa Convex Action
      // (bcryptjs) antes de enviar. Aqui está só a estrutura do formulário.
      const passwordHash = `HASH_DE:${password}`; // troque pela chamada real de hash

      const userId = await registerUser({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim() || undefined,
        passwordHash,
        role,
      });
      onRegistered?.(userId as unknown as string);
    } catch (err: any) {
      setError(err.message ?? "Não foi possível criar sua conta.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 max-w-md mx-auto"
    >
      <p className="text-white text-lg font-semibold mb-1">Criar conta</p>
      <p className="text-zinc-500 text-sm mb-5">Entre no Apiaí Serviços em poucos passos</p>

      <p className="text-zinc-400 text-xs mb-2">Você é...</p>
      <div className="grid grid-cols-3 gap-2 mb-5">
        <RoleButton icon={User} label="Cliente" active={role === "cliente"} onClick={() => setRole("cliente")} />
        <RoleButton
          icon={Briefcase}
          label="Profissional"
          active={role === "profissional"}
          onClick={() => setRole("profissional")}
        />
        <RoleButton
          icon={Building2}
          label="Empresa"
          active={role === "empresa"}
          onClick={() => setRole("empresa")}
        />
      </div>

      <Field icon={User} placeholder="Nome completo" value={name} onChange={setName} />
      <Field icon={Mail} placeholder="E-mail" type="email" value={email} onChange={setEmail} />
      <Field icon={Phone} placeholder="Telefone (WhatsApp)" value={phone} onChange={setPhone} />
      <Field icon={Lock} placeholder="Senha (mín. 6 caracteres)" type="password" value={password} onChange={setPassword} />

      {error && <p className="text-red-400 text-xs mb-3">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium disabled:opacity-60"
      >
        {loading && <Loader2 size={15} className="animate-spin" />}
        {loading ? "Criando conta..." : "Criar conta"}
      </button>
    </form>
  );
}

function RoleButton({
  icon: Icon,
  label,
  active,
  onClick,
}: {
  icon: any;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex flex-col items-center gap-1.5 py-3 rounded-lg border transition-colors ${
        active ? "border-amber-500 bg-amber-500/10 text-amber-400" : "border-zinc-800 text-zinc-400"
      }`}
    >
      <Icon size={18} />
      <span className="text-xs">{label}</span>
    </button>
  );
}

function Field({
  icon: Icon,
  placeholder,
  value,
  onChange,
  type = "text",
}: {
  icon: any;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <div className="relative mb-3">
      <Icon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-zinc-500 outline-none focus:border-amber-500/50"
      />
    </div>
  );
}

// ----------------------------------------------------------------------
// EXEMPLO — hash real de senha numa Convex Action (não numa mutation):
//
// // convex/authActions.ts
// "use node";
// import bcrypt from "bcryptjs";
// import { action } from "./_generated/server";
// import { v } from "convex/values";
// import { api } from "./_generated/api";
//
// export const registerWithPassword = action({
//   args: { name: v.string(), email: v.string(), password: v.string(), role: v.string() },
//   handler: async (ctx, args) => {
//     const passwordHash = await bcrypt.hash(args.password, 10);
//     return await ctx.runMutation(api.auth.registerUser, { ...args, passwordHash });
//   },
// });
// ----------------------------------------------------------------------

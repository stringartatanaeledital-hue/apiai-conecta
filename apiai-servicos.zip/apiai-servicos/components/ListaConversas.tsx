"use client";

// ============================================================================
// components/ListaConversas.tsx — Apiaí Serviços
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { MessageCircle } from "lucide-react";

export default function ListaConversas({
  userId,
  onSelect,
}: {
  userId: Id<"users">;
  onSelect: (conversationId: Id<"conversations">) => void;
}) {
  const conversations = useQuery(api.chat.listMyConversations, { userId });

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-zinc-800">
        <MessageCircle size={16} className="text-amber-400" />
        <p className="text-white text-sm font-medium">Mensagens</p>
      </div>

      <div className="divide-y divide-zinc-800">
        {conversations?.map((c) => (
          <button
            key={c._id}
            onClick={() => onSelect(c._id)}
            className="w-full flex items-center gap-3 px-4 py-3 hover:bg-zinc-800/50 text-left"
          >
            {c.otherUserPhotoUrl ? (
              <img src={c.otherUserPhotoUrl} className="w-10 h-10 rounded-full object-cover" alt="" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400 text-xs">
                {c.otherUserName.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{c.otherUserName}</p>
              <p className="text-zinc-500 text-xs truncate">
                {c.lastMessagePreview ?? "Nova conversa"}
              </p>
            </div>
            {c.unreadCount > 0 && (
              <span className="bg-amber-500 text-black text-[10px] font-semibold rounded-full w-5 h-5 flex items-center justify-center">
                {c.unreadCount}
              </span>
            )}
          </button>
        ))}
        {conversations?.length === 0 && (
          <p className="text-zinc-500 text-sm px-4 py-6 text-center">Nenhuma conversa ainda.</p>
        )}
      </div>
    </div>
  );
}

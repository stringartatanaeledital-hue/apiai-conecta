"use client";

// ============================================================================
// components/BuscarProfissionais.tsx — Apiaí Serviços
// Lista/busca de profissionais filtrando pela mesma taxonomia usada no
// cadastro (CadastroProfissional.tsx) e na tela do cliente (ClienteHome.tsx)
// ============================================================================

import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { DEPARTAMENTOS } from "@/lib/categoriasProfissoes";
import { Star, MapPin } from "lucide-react";

export default function BuscarProfissionais({
  initialCategory,
  initialSubcategory,
}: {
  initialCategory?: string;
  initialSubcategory?: string;
}) {
  const [category, setCategory] = useState<string | undefined>(initialCategory);
  const [subcategory, setSubcategory] = useState<string | undefined>(initialSubcategory);

  const professionals = useQuery(api.profissionaisBusca.searchProfessionals, {
    category,
    subcategory,
  });

  const departamento = DEPARTAMENTOS.find((d) => d.key === category);

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-4">
        {DEPARTAMENTOS.map((dept) => (
          <button
            key={dept.key}
            onClick={() => {
              setCategory(category === dept.key ? undefined : dept.key);
              setSubcategory(undefined);
            }}
            className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${
              category === dept.key
                ? "border-amber-500 bg-amber-500/10 text-amber-400"
                : "border-zinc-800 text-zinc-400 hover:border-zinc-700"
            }`}
          >
            {dept.label}
          </button>
        ))}
      </div>

      {departamento && (
        <div className="flex flex-wrap gap-1.5 mb-5">
          {departamento.profissoes.map((prof) => (
            <button
              key={prof}
              onClick={() => setSubcategory(subcategory === prof ? undefined : prof)}
              className={`text-[11px] px-2.5 py-1 rounded-md transition-colors ${
                subcategory === prof
                  ? "bg-amber-500 text-black font-medium"
                  : "bg-zinc-800 text-zinc-300"
              }`}
            >
              {prof}
            </button>
          ))}
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {professionals?.map((p: any) => (
          <div key={p._id} className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
            <div className="aspect-square bg-zinc-800">
              {p.photoUrl && (
                <img src={p.photoUrl} alt={p.name} className="w-full h-full object-cover" />
              )}
            </div>
            <div className="p-3">
              <p className="text-white text-sm font-medium truncate">{p.name}</p>
              <p className="text-zinc-500 text-xs">{p.subcategory}</p>
              <div className="flex items-center justify-between mt-2">
                <span className="flex items-center gap-1 text-amber-400 text-xs">
                  <Star size={11} className="fill-amber-400" /> {p.rating ?? "—"}
                </span>
                {p.distanceKm && (
                  <span className="flex items-center gap-1 text-zinc-500 text-xs">
                    <MapPin size={11} /> {p.distanceKm} km
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
        {professionals?.length === 0 && (
          <p className="text-zinc-500 text-sm col-span-full">
            Nenhum profissional encontrado para esse filtro ainda.
          </p>
        )}
      </div>
    </div>
  );
}

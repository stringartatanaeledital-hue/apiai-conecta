"use client";

// ============================================================================
// components/Configuracoes.tsx — Apiaí Serviços
// ============================================================================

import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { useSession } from "@/lib/SessionContext";
import { User, Phone, MapPin, LogOut } from "lucide-react";

export default function Configuracoes({ userId }: { userId: Id<"users"> }) {
  const { user, logout } = useSession();
  const updateProfile = useMutation(api.auth.updateProfile);

  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState("");
  const [cityLabel, setCityLabel] = useState("");
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    await updateProfile({
      userId,
      name: name.trim() || undefined,
      phone: phone.trim() || undefined,
      cityLabel: cityLabel.trim() || undefined,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 max-w-md">
      <p className="text-white text-lg font-semibold mb-1">Configurações</p>
      <p className="text-zinc-500 text-sm mb-5">Gerencie os dados da sua conta</p>

      <Field icon={User} placeholder="Nome" value={name} onChange={setName} />
      <Field icon={Phone} placeholder="Telefone" value={phone} onChange={setPhone} />
      <Field icon={MapPin} placeholder="Cidade" value={cityLabel} onChange={setCityLabel} />

      <button
        onClick={handleSave}
        className="w-full py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium mb-3"
      >
        {saved ? "Salvo!" : "Salvar alterações"}
      </button>

      <button
        onClick={logout}
        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-zinc-800 text-zinc-400 text-sm"
      >
        <LogOut size={15} /> Sair da conta
      </button>
    </div>
  );
}

function Field({
  icon: Icon,
  placeholder,
  value,
  onChange,
}: {
  icon: any;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="relative mb-3">
      <Icon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-zinc-500 outline-none focus:border-amber-500/50"
      />
    </div>
  );
}

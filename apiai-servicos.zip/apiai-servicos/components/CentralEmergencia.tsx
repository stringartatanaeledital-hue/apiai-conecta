"use client";

// ============================================================================
// components/CentralEmergencia.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Key, Truck, Zap, Wrench, Phone } from "lucide-react";

const CATEGORIES = [
  { key: "chaveiro", label: "Chaveiro", icon: Key },
  { key: "guincho", label: "Guincho", icon: Truck },
  { key: "eletricista", label: "Eletricista", icon: Zap },
  { key: "encanador", label: "Encanador", icon: Wrench },
] as const;

export default function CentralEmergencia() {
  const providers = useQuery(api.emergencia.listAll24h);

  return (
    <div className="rounded-xl border border-red-900/40 bg-red-950/20 p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
        <p className="text-white text-sm font-medium">Central de emergência 24h</p>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-4">
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const count = providers?.filter((p) => p.category === cat.key).length ?? 0;
          return (
            <div key={cat.key} className="rounded-lg bg-zinc-900/60 border border-zinc-800 p-3 text-center">
              <Icon size={18} className="text-red-400 mx-auto mb-1" />
              <p className="text-white text-xs">{cat.label}</p>
              <p className="text-zinc-500 text-[10px]">{count} disponíveis</p>
            </div>
          );
        })}
      </div>

      <div className="space-y-2">
        {providers?.slice(0, 4).map((p) => (
          <div key={p._id} className="flex items-center justify-between text-sm">
            <div>
              <p className="text-white">{p.name}</p>
              <p className="text-zinc-500 text-xs capitalize">{p.category}</p>
            </div>
            <a
              href={`tel:${p.phone}`}
              className="flex items-center gap-1.5 text-red-400 text-xs font-medium bg-red-500/10 px-3 py-1.5 rounded-lg"
            >
              <Phone size={12} /> Ligar
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

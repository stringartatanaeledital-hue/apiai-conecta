"use client";

// ============================================================================
// components/Fidelidade.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Gem } from "lucide-react";

const TIER_STYLE: Record<string, { label: string; className: string; next: number | null }> = {
  bronze: { label: "Bronze", className: "text-orange-400", next: 1500 },
  prata: { label: "Prata", className: "text-zinc-300", next: 5000 },
  ouro: { label: "Ouro", className: "text-amber-400", next: null },
};

export default function Fidelidade({ userId }: { userId: Id<"users"> }) {
  const account = useQuery(api.fidelidade.getAccount, { userId });
  const history = useQuery(api.fidelidade.listHistory, { userId });

  if (!account) return null;
  const tier = TIER_STYLE[account.tier];
  const progress = tier.next ? Math.min(100, (account.points / tier.next) * 100) : 100;

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
          <Gem size={18} className={tier.className} />
        </div>
        <div>
          <p className={`text-sm font-medium ${tier.className}`}>Nível {tier.label}</p>
          <p className="text-zinc-500 text-xs">{account.points} pontos</p>
        </div>
      </div>

      {tier.next && (
        <div className="mb-4">
          <div className="h-2 rounded-full bg-zinc-800 overflow-hidden">
            <div className="h-full bg-amber-500" style={{ width: `${progress}%` }} />
          </div>
          <p className="text-zinc-500 text-[10px] mt-1">
            Faltam {tier.next - account.points} pontos para o próximo nível
          </p>
        </div>
      )}

      <div className="space-y-2">
        {history?.slice(0, 5).map((h) => (
          <div key={h._id} className="flex items-center justify-between text-sm">
            <span className="text-zinc-400">{h.reason}</span>
            <span className={h.points >= 0 ? "text-emerald-400" : "text-red-400"}>
              {h.points >= 0 ? "+" : ""}
              {h.points} pts
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

"use client";

// ============================================================================
// components/PainelConvidados.tsx — Apiaí Serviços
// Só o dono/administrador decide quem usa o acesso gratuito. Aqui aparecem
// as solicitações pendentes (de quem clicou no link) pra aprovar ou negar,
// além de um atalho pra adicionar alguém direto, sem passar por solicitação.
// ============================================================================

import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { UserPlus, X, Gift, Check, Clock } from "lucide-react";

export default function PainelConvidados({ adminUserId }: { adminUserId?: Id<"users"> }) {
  const pendingRequests = useQuery(api.convites.listPendingRequests);
  const guests = useQuery(api.convites.listGuests);
  const approveRequest = useMutation(api.convites.approveRequest);
  const denyRequest = useMutation(api.convites.denyRequest);
  const addGuest = useMutation(api.convites.addGuestAccess);
  const revokeGuest = useMutation(api.convites.revokeGuestAccess);

  const [userId, setUserId] = useState("");
  const [benefit, setBenefit] = useState("Acesso Premium grátis");
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  async function handleAdd() {
    if (!userId.trim()) return;
    setSaving(true);
    try {
      const result = await addGuest({
        userId: userId.trim() as Id<"users">,
        benefitDescription: benefit,
        grantedBy: adminUserId,
      });
      setFeedback(result.alreadyGuest ? "Esse usuário já é convidado." : "Convidado adicionado!");
      setUserId("");
    } catch {
      setFeedback("ID de usuário inválido.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-5">
      {/* Solicitações pendentes — quem clicou no link espera sua decisão aqui */}
      <div className="rounded-xl border border-amber-500/30 bg-zinc-900/60 p-5">
        <div className="flex items-center gap-2 mb-1">
          <Clock size={16} className="text-amber-400" />
          <p className="text-white text-sm font-medium">Solicitações pendentes</p>
        </div>
        <p className="text-zinc-500 text-xs mb-4">
          Só você decide quem entra de graça — aprove ou negue cada uma.
        </p>

        <div className="space-y-2">
          {pendingRequests?.map((r) => (
            <div
              key={r._id}
              className="flex items-center justify-between bg-zinc-800/60 rounded-lg px-3 py-2"
            >
              <div>
                <p className="text-white text-sm">{(r.user as any)?.name ?? r.userId}</p>
                <p className="text-zinc-500 text-xs">
                  Solicitado em {new Date(r.requestedAt).toLocaleDateString("pt-BR")}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() =>
                    approveRequest({
                      requestId: r._id,
                      benefitDescription: benefit,
                      resolvedBy: adminUserId,
                    })
                  }
                  className="flex items-center gap-1 text-xs font-medium px-3 py-1.5 rounded-lg bg-amber-500 text-black"
                >
                  <Check size={13} /> Aprovar
                </button>
                <button
                  onClick={() => denyRequest({ requestId: r._id, resolvedBy: adminUserId })}
                  className="flex items-center gap-1 text-xs font-medium px-3 py-1.5 rounded-lg bg-zinc-800 text-zinc-300"
                >
                  <X size={13} /> Negar
                </button>
              </div>
            </div>
          ))}
          {pendingRequests?.length === 0 && (
            <p className="text-zinc-500 text-sm">Nenhuma solicitação pendente.</p>
          )}
        </div>
      </div>

      {/* Adicionar direto, sem esperar solicitação */}
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
        <div className="flex items-center gap-2 mb-1">
          <Gift size={16} className="text-amber-400" />
          <p className="text-white text-sm font-medium">Adicionar convidado direto</p>
        </div>
        <p className="text-zinc-500 text-xs mb-4">
          Sem link, sem solicitação — você libera na hora, quantas vezes quiser.
        </p>

        <div className="flex flex-col sm:flex-row gap-2 mb-2">
          <input
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            placeholder="ID do usuário"
            className="flex-1 bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
          />
          <input
            value={benefit}
            onChange={(e) => setBenefit(e.target.value)}
            placeholder="Benefício (ex: Acesso Premium grátis)"
            className="flex-1 bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
          />
          <button
            onClick={handleAdd}
            disabled={saving}
            className="flex items-center justify-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-amber-500 text-black disabled:opacity-50"
          >
            <UserPlus size={15} /> Adicionar
          </button>
        </div>
        {feedback && <p className="text-zinc-400 text-xs mb-2">{feedback}</p>}

        <div className="space-y-2 mt-3">
          {guests?.map((g) => (
            <div
              key={g._id}
              className="flex items-center justify-between text-sm bg-zinc-800/60 rounded-lg px-3 py-2"
            >
              <div>
                <p className="text-white">{(g.user as any)?.name ?? g.userId}</p>
                <p className="text-zinc-500 text-xs">{g.benefitDescription}</p>
              </div>
              <button
                onClick={() => revokeGuest({ grantId: g._id })}
                className="text-zinc-500 hover:text-red-400"
                aria-label="Remover convidado"
              >
                <X size={16} />
              </button>
            </div>
          ))}
          {guests?.length === 0 && (
            <p className="text-zinc-500 text-sm">Nenhum convidado adicionado ainda.</p>
          )}
        </div>

        <p className="text-zinc-600 text-xs mt-4">
          Total de convidados ativos: {guests?.filter((g) => g.isActive).length ?? 0}
        </p>
      </div>
    </div>
  );
}

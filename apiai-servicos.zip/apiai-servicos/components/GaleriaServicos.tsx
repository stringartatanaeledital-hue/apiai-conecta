"use client";

// ============================================================================
// components/GaleriaServicos.tsx — Apiaí Serviços
// Vitrine de fotos dos serviços feitos — pensado pra marcenarias, mas serve
// pra qualquer profissional/empresa mostrar o trabalho com fotos e preço.
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Hammer, Tag } from "lucide-react";

function formatBRL(cents?: number) {
  if (cents === undefined) return null;
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function GaleriaDoProfissional({ ownerId }: { ownerId: Id<"users"> }) {
  const items = useQuery(api.galeriaServicos.listByOwner, { ownerId });

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Hammer size={16} className="text-amber-400" />
        <p className="text-white text-sm font-medium">Trabalhos realizados</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {items?.map((item) => (
          <div key={item._id} className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
            <div className="aspect-square bg-zinc-800">
              {item.imageUrls[0] && (
                <img src={item.imageUrls[0] ?? undefined} alt={item.title} className="w-full h-full object-cover" />
              )}
            </div>
            <div className="p-3">
              <p className="text-white text-sm font-medium line-clamp-1">{item.title}</p>
              {item.description && (
                <p className="text-zinc-500 text-xs mt-0.5 line-clamp-2">{item.description}</p>
              )}
              {item.priceCents !== undefined && (
                <span className="flex items-center gap-1 text-amber-400 text-xs font-medium mt-2">
                  <Tag size={11} /> {formatBRL(item.priceCents)}
                </span>
              )}
            </div>
          </div>
        ))}
        {items?.length === 0 && (
          <p className="text-zinc-500 text-sm col-span-full">
            Nenhum trabalho publicado na galeria ainda.
          </p>
        )}
      </div>
    </div>
  );
}

// Vitrine geral — ex: "todas as marcenarias" (usa category = "Marcenaria")
export function VitrineDaCategoria({ category }: { category: string }) {
  const items = useQuery(api.galeriaServicos.listByCategory, { category });

  return (
    <div>
      <p className="text-white text-sm font-medium mb-4">{category} — trabalhos da região</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {items?.map((item) => (
          <div key={item._id} className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
            <div className="aspect-square bg-zinc-800">
              {item.imageUrls[0] && (
                <img src={item.imageUrls[0] ?? undefined} alt={item.title} className="w-full h-full object-cover" />
              )}
            </div>
            <div className="p-3">
              <p className="text-white text-sm font-medium line-clamp-1">{item.title}</p>
              <p className="text-zinc-500 text-xs mt-0.5">{item.ownerName}</p>
              {item.priceCents !== undefined && (
                <span className="text-amber-400 text-xs font-medium">{formatBRL(item.priceCents)}</span>
              )}
            </div>
          </div>
        ))}
        {items?.length === 0 && (
          <p className="text-zinc-500 text-sm col-span-full">
            Nenhum trabalho publicado nessa categoria ainda.
          </p>
        )}
      </div>
    </div>
  );
}

"use client";

// ============================================================================
// components/Financeiro.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { Wallet, TrendingUp, TrendingDown, Percent, QrCode } from "lucide-react";

function formatBRL(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function Financeiro({ ownerId }: { ownerId: Id<"users"> }) {
  const summary = useQuery(api.financeiro.getSummary, { ownerId, sinceDays: 30 });
  const timeline = useQuery(api.financeiro.getRevenueTimeline, { ownerId, days: 7 });
  const transactions = useQuery(api.financeiro.listTransactions, { ownerId });

  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
        <StatCard icon={Wallet} label="Saldo" value={formatBRL(summary?.saldoCents ?? 0)} highlight />
        <StatCard icon={TrendingUp} label="Receita" value={formatBRL(summary?.totals.receita ?? 0)} />
        <StatCard icon={TrendingDown} label="Despesas" value={formatBRL(summary?.totals.despesa ?? 0)} />
        <StatCard icon={Percent} label="Comissões" value={formatBRL(summary?.totals.comissao ?? 0)} />
        <StatCard icon={QrCode} label="Pix" value={formatBRL(summary?.totals.pix ?? 0)} />
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 mb-6">
        <p className="text-white text-sm font-medium mb-4">Receita — últimos 7 dias</p>
        <div style={{ width: "100%", height: 180 }}>
          <ResponsiveContainer>
            <LineChart data={timeline ?? []}>
              <XAxis dataKey="day" stroke="#71717a" fontSize={11} />
              <Tooltip
                formatter={(v: number) => formatBRL(v)}
                contentStyle={{ background: "#18181b", border: "1px solid #27272a", borderRadius: 8 }}
                labelStyle={{ color: "#fff" }}
              />
              <Line type="monotone" dataKey="amountCents" stroke="#f5a623" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
        <p className="text-white text-sm font-medium mb-3">Histórico</p>
        <div className="space-y-2">
          {transactions?.slice(0, 10).map((t) => (
            <div key={t._id} className="flex items-center justify-between text-sm">
              <div>
                <p className="text-white">{t.description}</p>
                <p className="text-zinc-500 text-xs">
                  {new Date(t.createdAt).toLocaleDateString("pt-BR")}
                </p>
              </div>
              <span
                className={
                  t.type === "despesa" || t.type === "comissao" ? "text-red-400" : "text-emerald-400"
                }
              >
                {t.type === "despesa" || t.type === "comissao" ? "-" : "+"}
                {formatBRL(t.amountCents)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  highlight,
}: {
  icon: any;
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
      <Icon size={16} className={highlight ? "text-amber-400" : "text-zinc-500"} />
      <p className={`text-sm font-semibold mt-2 ${highlight ? "text-amber-400" : "text-white"}`}>
        {value}
      </p>
      <p className="text-zinc-500 text-xs">{label}</p>
    </div>
  );
}

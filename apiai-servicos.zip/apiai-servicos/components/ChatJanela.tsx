"use client";

// ============================================================================
// components/ChatJanela.tsx — Apiaí Serviços
// Janela de chat direto entre cliente e profissional.
// ============================================================================

import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Send, Image as ImageIcon } from "lucide-react";

export default function ChatJanela({
  conversationId,
  currentUserId,
}: {
  conversationId: Id<"conversations">;
  currentUserId: Id<"users">;
}) {
  const messages = useQuery(api.chat.listMessages, { conversationId });
  const sendMessage = useMutation(api.chat.sendMessage);
  const markAsRead = useMutation(api.chat.markAsRead);
  const generateUploadUrl = useMutation(api.chat.generateUploadUrl);

  const [text, setText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    markAsRead({ conversationId, readerId: currentUserId });
  }, [conversationId, currentUserId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend() {
    if (!text.trim()) return;
    await sendMessage({ conversationId, senderId: currentUserId, text: text.trim() });
    setText("");
  }

  async function handleImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const uploadUrl = await generateUploadUrl();
    const result = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": file.type }, body: file });
    const { storageId } = await result.json();
    await sendMessage({ conversationId, senderId: currentUserId, imageStorageId: storageId });
  }

  return (
    <div className="flex flex-col h-full rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages?.map((m) => {
          const mine = m.senderId === currentUserId;
          return (
            <div key={m._id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[70%] rounded-2xl px-3 py-2 ${
                  mine ? "bg-amber-500 text-black" : "bg-zinc-800 text-white"
                }`}
              >
                {m.imageUrl && (
                  <img src={m.imageUrl} alt="" className="rounded-lg mb-1 max-h-48 object-cover" />
                )}
                {m.text && <p className="text-sm">{m.text}</p>}
                <p className={`text-[10px] mt-1 ${mine ? "text-black/60" : "text-zinc-500"}`}>
                  {new Date(m.createdAt).toLocaleTimeString("pt-BR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <div className="flex items-center gap-2 p-3 border-t border-zinc-800">
        <label className="text-zinc-400 hover:text-amber-400 cursor-pointer">
          <ImageIcon size={20} />
          <input type="file" accept="image/*" onChange={handleImage} className="hidden" />
        </label>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Digite sua mensagem..."
          className="flex-1 bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
        />
        <button
          onClick={handleSend}
          className="w-9 h-9 rounded-lg bg-amber-500 text-black flex items-center justify-center"
          aria-label="Enviar"
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  );
}

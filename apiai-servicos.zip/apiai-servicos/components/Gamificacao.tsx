"use client";

// ============================================================================
// components/Gamificacao.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Medal, Trophy, Star, Crown } from "lucide-react";

const BADGE_STYLE: Record<string, { label: string; icon: any; className: string }> = {
  ouro: { label: "Ouro", icon: Medal, className: "bg-amber-500/15 text-amber-400" },
  prata: { label: "Prata", icon: Medal, className: "bg-zinc-400/15 text-zinc-300" },
  bronze: { label: "Bronze", icon: Medal, className: "bg-orange-700/15 text-orange-400" },
  top_atendimento: { label: "Top atendimento", icon: Trophy, className: "bg-blue-500/15 text-blue-400" },
  super_profissional: { label: "Super profissional", icon: Star, className: "bg-purple-500/15 text-purple-400" },
  elite: { label: "Elite", icon: Crown, className: "bg-amber-500/15 text-amber-300" },
};

export function BadgesRow({ professionalId }: { professionalId: Id<"users"> }) {
  const badges = useQuery(api.gamificacao.listBadgesByProfessional, { professionalId });

  if (!badges || badges.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2">
      {badges.map((b) => {
        const style = BADGE_STYLE[b.badgeType];
        const Icon = style.icon;
        return (
          <span
            key={b._id}
            title={b.reason}
            className={`inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full ${style.className}`}
          >
            <Icon size={12} />
            {style.label}
          </span>
        );
      })}
    </div>
  );
}

export function RankingProfissionais() {
  const ranking = useQuery(api.gamificacao.topRankedProfessionals, { limit: 10 });

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <p className="text-white text-sm font-medium mb-4">Ranking de profissionais</p>
      <div className="space-y-3">
        {ranking?.map((p, i) => (
          <div key={p.professionalId} className="flex items-center gap-3">
            <span className="text-zinc-500 text-sm w-4">{i + 1}</span>
            {p.photoUrl ? (
              <img src={p.photoUrl} alt={p.name} className="w-8 h-8 rounded-full object-cover" />
            ) : (
              <div className="w-8 h-8 rounded-full bg-zinc-800" />
            )}
            <span className="text-white text-sm flex-1">{p.name}</span>
            <span className="flex items-center gap-1 text-amber-400 text-xs font-medium">
              <Medal size={12} /> {p.badgeCount}
            </span>
          </div>
        ))}
        {ranking?.length === 0 && (
          <p className="text-zinc-500 text-sm">Nenhuma medalha concedida ainda.</p>
        )}
      </div>
    </div>
  );
}

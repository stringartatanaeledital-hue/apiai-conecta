"use client";

// ============================================================================
// components/Login.tsx — Apiaí Serviços
// ============================================================================

import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useSession } from "@/lib/SessionContext";
import { Mail, Lock, Loader2 } from "lucide-react";

export default function Login({ onLoggedIn }: { onLoggedIn?: () => void }) {
  const { login } = useSession();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const userData = useQuery(api.auth.getUserForLogin, submitted ? { email } : "skip");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email.trim() || !password) {
      setError("Preencha e-mail e senha.");
      return;
    }
    setSubmitted(true);
  }

  // Quando o resultado da query chega, valide a senha e finalize o login.
  // ATENÇÃO: a comparação abaixo é um placeholder (mesmo esquema usado no
  // cadastro). Em produção, essa checagem deve rodar numa Convex Action com
  // bcrypt.compare(password, user.passwordHash) — nunca compare no cliente.
  if (submitted && userData !== undefined && !error) {
    if (!userData) {
      setError("E-mail ou senha inválidos.");
      setSubmitted(false);
    } else if (userData.passwordHash === `HASH_DE:${password}`) {
      login({
        userId: userData._id,
        name: userData.name,
        email: userData.email,
        role: userData.role,
      });
      onLoggedIn?.();
    } else {
      setError("E-mail ou senha inválidos.");
      setSubmitted(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 max-w-md mx-auto"
    >
      <p className="text-white text-lg font-semibold mb-1">Entrar</p>
      <p className="text-zinc-500 text-sm mb-5">Acesse sua conta no Apiaí Serviços</p>

      <div className="relative mb-3">
        <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="E-mail"
          className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-zinc-500 outline-none focus:border-amber-500/50"
        />
      </div>

      <div className="relative mb-4">
        <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Senha"
          className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-zinc-500 outline-none focus:border-amber-500/50"
        />
      </div>

      {error && <p className="text-red-400 text-xs mb-3">{error}</p>}

      <button
        type="submit"
        disabled={submitted}
        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium disabled:opacity-60"
      >
        {submitted && <Loader2 size={15} className="animate-spin" />}
        {submitted ? "Entrando..." : "Entrar"}
      </button>
    </form>
  );
}

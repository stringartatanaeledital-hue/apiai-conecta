"use client";

// ============================================================================
// components/Cursos.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { GraduationCap, ShieldCheck, Clock } from "lucide-react";

function formatBRL(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function Cursos({ userId }: { userId: Id<"users"> }) {
  const courses = useQuery(api.cursos.listCourses, {});
  const enroll = useMutation(api.cursos.enroll);

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
      {courses?.map((course) => (
        <div key={course._id} className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
          <div className="aspect-video bg-zinc-800 flex items-center justify-center">
            {course.thumbnailUrl ? (
              <img src={course.thumbnailUrl} className="w-full h-full object-cover" alt={course.title} />
            ) : (
              <GraduationCap size={28} className="text-zinc-600" />
            )}
          </div>
          <div className="p-4">
            <div className="flex items-center gap-2 mb-2">
              {course.isNR && (
                <span className="flex items-center gap-1 text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md font-medium">
                  <ShieldCheck size={10} /> {course.nrNumber}
                </span>
              )}
              <span className="text-[10px] text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded-md">
                {course.type === "presencial" ? "Presencial" : "Online"}
              </span>
            </div>
            <p className="text-white text-sm font-medium line-clamp-2">{course.title}</p>
            <div className="flex items-center gap-1 text-zinc-500 text-xs mt-1.5">
              <Clock size={12} /> {course.durationHours}h
            </div>
            <div className="flex items-center justify-between mt-3">
              <span className="text-amber-400 text-sm font-semibold">
                {course.priceCents === 0 ? "Gratuito" : formatBRL(course.priceCents)}
              </span>
              <button
                onClick={() => enroll({ courseId: course._id, userId })}
                className="text-xs font-medium px-3 py-1.5 rounded-lg bg-amber-500 text-black"
              >
                Inscrever-se
              </button>
            </div>
          </div>
        </div>
      ))}
      {courses?.length === 0 && (
        <p className="text-zinc-500 text-sm col-span-full">Nenhum curso disponível ainda.</p>
      )}
    </div>
  );
}

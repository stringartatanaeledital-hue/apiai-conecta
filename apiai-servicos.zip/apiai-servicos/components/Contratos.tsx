"use client";

// ============================================================================
// components/Contratos.tsx — ATAMURA SERVIÇOS Ω
// Requer: npm install qrcode.react
// ============================================================================

import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { QRCodeSVG } from "qrcode.react";
import { FileText, ShieldCheck, Check, Clock } from "lucide-react";

export default function ContratoCard({
  contractId,
  viewerRole,
}: {
  contractId: Id<"contracts">;
  viewerRole: "cliente" | "profissional";
}) {
  const contract = useQuery(api.contratos.getContract, { contractId });
  const sign = useMutation(api.contratos.signContract);

  if (contract === undefined) {
    return <div className="h-56 rounded-xl bg-zinc-900/60 border border-zinc-800 animate-pulse" />;
  }
  if (contract === null) return null;

  const mySigned =
    viewerRole === "cliente" ? contract.signedByClient : contract.signedByProfessional;
  const otherSigned =
    viewerRole === "cliente" ? contract.signedByProfessional : contract.signedByClient;

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
          <FileText size={18} className="text-amber-400" />
        </div>
        <div className="flex-1">
          <p className="text-white text-sm font-medium">Contrato de prestação de serviço</p>
          {contract.warrantyMonths && (
            <p className="text-zinc-500 text-xs">Garantia: {contract.warrantyMonths} meses</p>
          )}
        </div>
        <StatusBadge status={contract.status} />
      </div>

      <div className="flex items-center gap-6 mb-4">
        <div className="bg-white p-2 rounded-lg">
          <QRCodeSVG value={contract.qrCodeToken} size={88} />
        </div>
        <div className="flex-1 space-y-2">
          <SignRow label="Cliente" signed={contract.signedByClient} />
          <SignRow label="Profissional" signed={contract.signedByProfessional} />
        </div>
      </div>

      {contract.pdfUrl && (
        <a
          href={contract.pdfUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-amber-400 text-xs underline"
        >
          Ver PDF do contrato
        </a>
      )}

      {!mySigned && contract.status !== "cancelado" && (
        <button
          onClick={() => sign({ contractId, signer: viewerRole })}
          className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium"
        >
          <ShieldCheck size={16} />
          Assinar contrato digitalmente
        </button>
      )}

      {mySigned && !otherSigned && (
        <p className="mt-4 text-zinc-500 text-xs flex items-center gap-1.5">
          <Clock size={12} /> Aguardando assinatura da outra parte
        </p>
      )}
    </div>
  );
}

function SignRow({ label, signed }: { label: string; signed: boolean }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <div
        className={`w-5 h-5 rounded-full flex items-center justify-center ${
          signed ? "bg-amber-500" : "bg-zinc-800"
        }`}
      >
        {signed && <Check size={12} className="text-black" />}
      </div>
      <span className={signed ? "text-white" : "text-zinc-500"}>{label}</span>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; className: string }> = {
    aguardando_assinatura: { label: "Aguardando", className: "bg-zinc-800 text-zinc-300" },
    assinado: { label: "Assinado", className: "bg-emerald-500/20 text-emerald-400" },
    cancelado: { label: "Cancelado", className: "bg-red-500/20 text-red-400" },
  };
  const s = map[status] ?? map.aguardando_assinatura;
  return (
    <span className={`text-xs px-2 py-1 rounded-md font-medium ${s.className}`}>{s.label}</span>
  );
}

"use client";

// ============================================================================
// components/Empresas.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Building2, Users, Truck, Wrench } from "lucide-react";

export default function EmpresaCard({ companyId }: { companyId: Id<"companies"> }) {
  const company = useQuery(api.empresas.getCompany, { companyId });

  if (company === undefined) {
    return <div className="h-40 rounded-xl bg-zinc-900/60 border border-zinc-800 animate-pulse" />;
  }
  if (company === null) return null;

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <div className="flex items-center gap-3 mb-4">
        {company.logoUrl ? (
          <img src={company.logoUrl} alt={company.name} className="w-12 h-12 rounded-lg object-cover" />
        ) : (
          <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center">
            <Building2 size={22} className="text-amber-400" />
          </div>
        )}
        <div>
          <p className="text-white font-medium">{company.name}</p>
          {company.cnpj && <p className="text-zinc-500 text-xs">CNPJ: {company.cnpj}</p>}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-4">
        <StatBox icon={Users} label="Funcionários" value={company.employeesCount} />
        <StatBox icon={Truck} label="Veículos" value={company.vehiclesCount} />
        <StatBox icon={Truck} label="Caminhões" value={company.trucksCount} />
        <StatBox icon={Wrench} label="Equipes" value={company.teamsCount} />
      </div>

      {company.employees.length > 0 && (
        <div>
          <p className="text-zinc-400 text-xs mb-2">Equipe</p>
          <div className="space-y-1.5">
            {company.employees.slice(0, 5).map((e) => (
              <div key={e._id} className="flex items-center justify-between text-sm">
                <span className="text-white">{e.name}</span>
                <span className="text-zinc-500">{e.role}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatBox({ icon: Icon, label, value }: { icon: any; label: string; value: number }) {
  return (
    <div className="rounded-lg bg-zinc-800/60 p-2.5 text-center">
      <Icon size={16} className="text-amber-400 mx-auto mb-1" />
      <p className="text-white text-sm font-semibold">{value}</p>
      <p className="text-zinc-500 text-[10px]">{label}</p>
    </div>
  );
}

"use client";

// ============================================================================
// components/MapaInteligente.tsx — ATAMURA SERVIÇOS Ω
// Requer: npm install react-map-gl mapbox-gl (ou substitua pelo provedor de
// mapa já usado no seu projeto — este componente foca na lógica de camadas).
// ============================================================================

import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Users, Building2, Store, HardHat, Siren } from "lucide-react";

const LAYERS = [
  { key: "profissionais", label: "Profissionais", icon: Users, color: "#f5a623" },
  { key: "empresas", label: "Empresas", icon: Building2, color: "#3b82f6" },
  { key: "lojas", label: "Lojas", icon: Store, color: "#10b981" },
  { key: "obras", label: "Obras", icon: HardHat, color: "#eab308" },
  { key: "emergencia", label: "Emergência", icon: Siren, color: "#ef4444" },
] as const;

export default function MapaInteligente() {
  const [activeLayers, setActiveLayers] = useState<Set<string>>(new Set(["profissionais"]));

  function toggle(layer: string) {
    setActiveLayers((prev) => {
      const next = new Set(prev);
      next.has(layer) ? next.delete(layer) : next.add(layer);
      return next;
    });
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
      <div className="flex gap-2 p-4 border-b border-zinc-800 overflow-x-auto">
        {LAYERS.map((layer) => {
          const Icon = layer.icon;
          const active = activeLayers.has(layer.key);
          return (
            <button
              key={layer.key}
              onClick={() => toggle(layer.key)}
              className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border whitespace-nowrap transition-colors ${
                active ? "border-transparent" : "border-zinc-800 text-zinc-500"
              }`}
              style={active ? { backgroundColor: `${layer.color}22`, color: layer.color } : {}}
            >
              <Icon size={14} />
              {layer.label}
            </button>
          );
        })}
      </div>

      {/* Área do mapa — plugue aqui seu provedor real (Mapbox/Google Maps) */}
      <div className="aspect-video bg-zinc-950 relative flex items-center justify-center">
        <p className="text-zinc-600 text-sm">
          Mapa com {activeLayers.size} camada(s) ativa(s) — integre seu provedor de mapa aqui
        </p>
        {[...activeLayers].map((key) => (
          <LayerMarkers key={key} layerKey={key as any} />
        ))}
      </div>
    </div>
  );
}

function LayerMarkers({ layerKey }: { layerKey: "profissionais" | "empresas" | "emergencia" }) {
  const data = useQuery(api.mapa.getLayerData, { layer: layerKey });
  // Aqui você mapearia `data` para marcadores reais do seu provedor de mapa.
  // Mantido como hook de dados para você plugar na lib de mapa escolhida.
  void data;
  return null;
}

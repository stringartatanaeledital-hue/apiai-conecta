"use client";

// ============================================================================
// components/PainelAnalitico.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { BarChart, Bar, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { Eye, Users, Percent } from "lucide-react";

export default function PainelAnalitico({ professionalId }: { professionalId: Id<"users"> }) {
  const data = useQuery(api.analitico.getAnalytics, { professionalId, days: 30 });

  if (!data) return null;

  return (
    <div>
      <div className="grid grid-cols-3 gap-3 mb-6">
        <StatCard icon={Eye} label="Visualizações (30d)" value={data.totalViews} />
        <StatCard icon={Users} label="Contatos gerados" value={data.contactsGenerated} />
        <StatCard icon={Percent} label="Taxa de conversão" value={`${data.conversionRate}%`} />
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 mb-6">
        <p className="text-white text-sm font-medium mb-4">Visualizações por dia</p>
        <div style={{ width: "100%", height: 180 }}>
          <ResponsiveContainer>
            <BarChart data={data.timeline}>
              <XAxis dataKey="day" stroke="#71717a" fontSize={11} />
              <Tooltip
                contentStyle={{ background: "#18181b", border: "1px solid #27272a", borderRadius: 8 }}
                labelStyle={{ color: "#fff" }}
              />
              <Bar dataKey="count" fill="#f5a623" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
        <p className="text-white text-sm font-medium mb-3">Origem dos clientes</p>
        <div className="space-y-2">
          {Object.entries(data.bySource).map(([source, count]) => (
            <div key={source} className="flex items-center justify-between text-sm">
              <span className="text-zinc-400 capitalize">{source}</span>
              <span className="text-white">{count}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
      <Icon size={16} className="text-amber-400" />
      <p className="text-white text-lg font-semibold mt-2">{value}</p>
      <p className="text-zinc-500 text-xs">{label}</p>
    </div>
  );
}

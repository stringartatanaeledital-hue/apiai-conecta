"use client";

// ============================================================================
// components/ConviteResgate.tsx — Apiaí Serviços
// Tela que abre quando alguém clica no link de convite. NÃO libera acesso
// sozinha — só envia uma solicitação. Quem decide se libera é o dono,
// aprovando pelo PainelConvidados.tsx.
// ============================================================================

import { useEffect, useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Gift, CheckCircle2, Clock, XCircle } from "lucide-react";

export default function ConviteResgate({
  code,
  currentUserId,
}: {
  code: string;
  currentUserId: Id<"users">;
}) {
  const status = useQuery(api.convites.getInviteStatus, { code });
  const requestAccess = useMutation(api.convites.requestAccess);
  const myStatus = useQuery(api.convites.getMyRequestStatus, { userId: currentUserId });
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (status?.found && status.isActive && !sent) {
      requestAccess({ userId: currentUserId, code }).then(() => setSent(true));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  if (status === undefined || myStatus === undefined) {
    return <div className="h-40 rounded-xl bg-zinc-900/60 border border-zinc-800 animate-pulse" />;
  }
  if (!status.found || !status.isActive) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 text-center">
        <p className="text-zinc-400 text-sm">Este convite não está mais disponível.</p>
      </div>
    );
  }

  if (myStatus.status === "aprovado") {
    return (
      <div className="rounded-xl border border-amber-500/30 bg-zinc-900/60 p-6 text-center">
        <CheckCircle2 size={32} className="text-emerald-400 mx-auto mb-3" />
        <p className="text-white text-sm font-medium mb-1">Acesso liberado!</p>
        <p className="text-zinc-400 text-xs">{status.benefitDescription}</p>
      </div>
    );
  }

  if (myStatus.status === "negado") {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 text-center">
        <XCircle size={28} className="text-zinc-500 mx-auto mb-3" />
        <p className="text-white text-sm font-medium mb-1">Solicitação não aprovada</p>
        <p className="text-zinc-500 text-xs">Fale com quem te enviou o convite.</p>
      </div>
    );
  }

  // pendente (padrão logo após enviar a solicitação)
  return (
    <div className="rounded-xl border border-amber-500/30 bg-gradient-to-br from-amber-500/10 to-zinc-900/60 p-6 text-center">
      <div className="flex items-center justify-center gap-2 mb-2">
        <Gift size={18} className="text-amber-400" />
        <p className="text-white text-sm font-semibold">Solicitação enviada</p>
      </div>
      <p className="text-zinc-400 text-xs mb-3">{status.benefitDescription}</p>
      <div className="flex items-center justify-center gap-1.5 text-zinc-500 text-xs">
        <Clock size={13} /> Aguardando aprovação do administrador
      </div>
    </div>
  );
}

"use client";

// ============================================================================
// components/ClienteHome.tsx — Aplicativo do Cliente — APIAÍ SERVIÇOS
// Tela inicial "O que você precisa hoje?" com todos os departamentos e
// profissões (pintor, mecânico, jardineiro, roçador, caçamba, máquinas, etc.)
// ============================================================================

import { useState } from "react";
import {
  Hammer,
  Trees,
  Truck,
  Car,
  SprayCan,
  HardHat,
  ShieldCheck,
  Sparkles,
  HeartPulse,
  Dog,
  Laptop,
  Fan,
  PartyPopper,
  ChefHat,
  Scissors,
  Briefcase,
  BookOpen,
  Package,
  Tractor,
  ChevronRight,
} from "lucide-react";
import { DEPARTAMENTOS } from "@/lib/categoriasProfissoes";

const ICONS: Record<string, any> = {
  Hammer,
  Trees,
  Truck,
  Car,
  SprayCan,
  HardHat,
  ShieldCheck,
  Sparkles,
  HeartPulse,
  Dog,
  Laptop,
  Fan,
  PartyPopper,
  ChefHat,
  Scissors,
  Briefcase,
  BookOpen,
  Package,
  Tractor,
};

export default function ClienteHome({
  onSelectProfissao,
}: {
  onSelectProfissao: (departamentoKey: string, profissao: string) => void;
}) {
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6">
      <p className="text-white text-lg font-semibold mb-1">O que você precisa hoje?</p>
      <p className="text-zinc-500 text-sm mb-5">
        Encontre o profissional certo em Apiaí e região
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {DEPARTAMENTOS.map((dept) => {
          const Icon = ICONS[dept.icon] ?? Hammer;
          const isOpen = expanded === dept.key;
          return (
            <div key={dept.key} className="col-span-1">
              <button
                onClick={() => setExpanded(isOpen ? null : dept.key)}
                className={`w-full flex items-center gap-2.5 p-3 rounded-xl border transition-colors ${
                  isOpen
                    ? "border-amber-500 bg-amber-500/10"
                    : "border-zinc-800 hover:border-amber-500/50 hover:bg-amber-500/5"
                }`}
              >
                <Icon size={18} className="text-amber-400 flex-shrink-0" />
                <span className="text-zinc-200 text-xs text-left flex-1">{dept.label}</span>
                <ChevronRight
                  size={14}
                  className={`text-zinc-500 transition-transform ${isOpen ? "rotate-90" : ""}`}
                />
              </button>

              {isOpen && (
                <div className="mt-2 flex flex-wrap gap-1.5 px-1">
                  {dept.profissoes.map((prof) => (
                    <button
                      key={prof}
                      onClick={() => onSelectProfissao(dept.key, prof)}
                      className="text-[11px] text-zinc-300 bg-zinc-800 hover:bg-amber-500 hover:text-black px-2.5 py-1.5 rounded-md transition-colors"
                    >
                      {prof}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

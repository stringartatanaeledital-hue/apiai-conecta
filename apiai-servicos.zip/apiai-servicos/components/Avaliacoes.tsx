"use client";

// ============================================================================
// components/Avaliacoes.tsx — Apiaí Serviços
// ============================================================================

import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Star } from "lucide-react";

export function AvaliarServico({
  orderId,
  clientId,
  professionalId,
  onDone,
}: {
  orderId: Id<"serviceOrders">;
  clientId: Id<"users">;
  professionalId: Id<"users">;
  onDone?: () => void;
}) {
  const existingReview = useQuery(api.avaliacoes.getReviewForOrder, { orderId });
  const addReview = useMutation(api.avaliacoes.addReview);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);

  if (existingReview) {
    return (
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 text-center">
        <p className="text-zinc-400 text-sm">Você já avaliou este serviço. Obrigado!</p>
      </div>
    );
  }

  async function handleSubmit() {
    if (rating === 0) return;
    setSaving(true);
    try {
      await addReview({ orderId, clientId, professionalId, rating, comment: comment.trim() || undefined });
      onDone?.();
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <p className="text-white text-sm font-medium mb-1">Como foi o serviço?</p>
      <p className="text-zinc-500 text-xs mb-4">Sua avaliação ajuda outros clientes</p>

      <div className="flex justify-center gap-1.5 mb-4">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => setRating(star)}
            onMouseEnter={() => setHoverRating(star)}
            onMouseLeave={() => setHoverRating(0)}
          >
            <Star
              size={28}
              className={
                star <= (hoverRating || rating) ? "fill-amber-400 text-amber-400" : "text-zinc-700"
              }
            />
          </button>
        ))}
      </div>

      <textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Conte como foi (opcional)..."
        rows={3}
        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none mb-4 resize-none"
      />

      <button
        onClick={handleSubmit}
        disabled={rating === 0 || saving}
        className="w-full py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium disabled:bg-zinc-800 disabled:text-zinc-600"
      >
        {saving ? "Enviando..." : "Enviar avaliação"}
      </button>
    </div>
  );
}

export function ListaAvaliacoes({ professionalId }: { professionalId: Id<"users"> }) {
  const reviews = useQuery(api.avaliacoes.listByProfessional, { professionalId });
  const summary = useQuery(api.avaliacoes.getAverageRating, { professionalId });

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <div className="flex items-center gap-2 mb-4">
        <Star size={18} className="fill-amber-400 text-amber-400" />
        <p className="text-white text-lg font-semibold">{summary?.average ?? "—"}</p>
        <p className="text-zinc-500 text-sm">({summary?.count ?? 0} avaliações)</p>
      </div>

      <div className="space-y-3">
        {reviews?.map((r) => (
          <div key={r._id} className="border-t border-zinc-800 pt-3">
            <div className="flex items-center justify-between mb-1">
              <p className="text-white text-sm font-medium">{r.clientName}</p>
              <div className="flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={12}
                    className={i < r.rating ? "fill-amber-400 text-amber-400" : "text-zinc-700"}
                  />
                ))}
              </div>
            </div>
            {r.comment && <p className="text-zinc-400 text-sm">{r.comment}</p>}
          </div>
        ))}
        {reviews?.length === 0 && (
          <p className="text-zinc-500 text-sm">Nenhuma avaliação recebida ainda.</p>
        )}
      </div>
    </div>
  );
}

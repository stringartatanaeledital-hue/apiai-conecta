"use client";

// ============================================================================
// components/PainelClientes.tsx — Apiaí Serviços
// ============================================================================

import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Search, Mail, Phone, MapPin } from "lucide-react";

export default function PainelClientes() {
  const [search, setSearch] = useState("");
  const clients = useQuery(api.adminCategoriasClientes.listClients, {
    searchText: search || undefined,
  });

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <p className="text-white text-sm font-medium mb-1">Clientes</p>
      <p className="text-zinc-500 text-xs mb-4">{clients?.length ?? 0} clientes cadastrados</p>

      <div className="relative mb-4">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por nome ou e-mail"
          className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
        />
      </div>

      <div className="space-y-2">
        {clients?.map((c) => (
          <div key={c._id} className="flex items-center justify-between bg-zinc-800/60 rounded-lg px-3 py-2.5">
            <div>
              <p className="text-white text-sm">{c.name}</p>
              <div className="flex items-center gap-3 mt-0.5">
                <span className="flex items-center gap-1 text-zinc-500 text-xs">
                  <Mail size={11} /> {c.email}
                </span>
                {c.phone && (
                  <span className="flex items-center gap-1 text-zinc-500 text-xs">
                    <Phone size={11} /> {c.phone}
                  </span>
                )}
                {c.cityLabel && (
                  <span className="flex items-center gap-1 text-zinc-500 text-xs">
                    <MapPin size={11} /> {c.cityLabel}
                  </span>
                )}
              </div>
            </div>
            <span className="text-zinc-600 text-xs">
              {new Date(c.createdAt).toLocaleDateString("pt-BR")}
            </span>
          </div>
        ))}
        {clients?.length === 0 && (
          <p className="text-zinc-500 text-sm">Nenhum cliente encontrado.</p>
        )}
      </div>
    </div>
  );
}

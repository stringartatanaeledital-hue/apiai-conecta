"use client";

// ============================================================================
// components/ProfessionalFeed.tsx
// Feed dos Profissionais estilo Instagram — ATAMURA SERVIÇOS Ω
// Fotos, vídeos, antes/depois, promoções, obras e stories.
// ============================================================================

import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { usePaginatedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Heart, MessageCircle, Tag, Star } from "lucide-react";

const TYPE_BADGE: Record<string, { label: string; className: string }> = {
  foto: { label: "Foto", className: "bg-zinc-800 text-zinc-300" },
  video: { label: "Vídeo", className: "bg-zinc-800 text-zinc-300" },
  antes_depois: { label: "Antes e depois", className: "bg-blue-500/20 text-blue-300" },
  promocao: { label: "Promoção", className: "bg-amber-500/20 text-amber-400" },
  obra: { label: "Obra", className: "bg-emerald-500/20 text-emerald-400" },
};

// ---------------------------------------------------------------------
// Barra de stories no topo do feed
// ---------------------------------------------------------------------
function StoriesBar() {
  const stories = useQuery(api.professionalFeed.listActiveStories);

  if (!stories || stories.length === 0) return null;

  return (
    <div className="flex gap-4 overflow-x-auto pb-4 mb-4 border-b border-zinc-800">
      {stories.map((story) => (
        <button key={story._id} className="flex flex-col items-center gap-1 flex-shrink-0">
          <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-amber-500 to-amber-300">
            <div className="w-full h-full rounded-full bg-zinc-950 p-[2px]">
              <img
                src={story.professionalPhotoUrl ?? "/avatar-placeholder.png"}
                alt={story.professionalName}
                className="w-full h-full rounded-full object-cover"
              />
            </div>
          </div>
          <span className="text-xs text-zinc-400 max-w-[64px] truncate">
            {story.professionalName}
          </span>
        </button>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------
// Um card de post
// ---------------------------------------------------------------------
function PostCard({
  post,
  currentUserId,
}: {
  post: any;
  currentUserId: Id<"users">;
}) {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const toggleLike = useMutation(api.professionalFeed.toggleLike);
  const addComment = useMutation(api.professionalFeed.addComment);
  const comments = useQuery(
    api.professionalFeed.listComments,
    showComments ? { postId: post._id } : "skip"
  );

  const badge = TYPE_BADGE[post.type];

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
      {/* Cabeçalho */}
      <div className="flex items-center gap-3 p-4">
        <img
          src={post.professionalPhotoUrl ?? "/avatar-placeholder.png"}
          alt={post.professionalName}
          className="w-10 h-10 rounded-full object-cover"
        />
        <div className="flex-1">
          <p className="text-white text-sm font-medium">{post.professionalName}</p>
          {post.professionalCategory && (
            <p className="text-zinc-500 text-xs">{post.professionalCategory}</p>
          )}
        </div>
        {badge && (
          <span className={`text-xs px-2 py-1 rounded-md font-medium ${badge.className}`}>
            {badge.label}
          </span>
        )}
      </div>

      {/* Mídia */}
      {post.type === "antes_depois" ? (
        <div className="grid grid-cols-2 gap-0.5">
          <div className="relative">
            <img src={post.beforeUrl} alt="Antes" className="w-full aspect-square object-cover" />
            <span className="absolute top-2 left-2 text-xs bg-black/70 text-white px-2 py-0.5 rounded">
              Antes
            </span>
          </div>
          <div className="relative">
            <img src={post.afterUrl} alt="Depois" className="w-full aspect-square object-cover" />
            <span className="absolute top-2 left-2 text-xs bg-amber-500 text-black px-2 py-0.5 rounded font-medium">
              Depois
            </span>
          </div>
        </div>
      ) : (
        <div className="flex overflow-x-auto snap-x snap-mandatory">
          {post.mediaUrls.map((url: string, i: number) => (
            <img
              key={i}
              src={url}
              alt={`Mídia ${i + 1}`}
              className="w-full flex-shrink-0 snap-center aspect-square object-cover"
            />
          ))}
        </div>
      )}

      {/* Promoção */}
      {post.type === "promocao" && post.promoDiscountPercent && (
        <div className="mx-4 mt-3 flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-lg px-3 py-2">
          <Tag size={16} className="text-amber-400" />
          <span className="text-amber-400 text-sm font-medium">
            {post.promoDiscountPercent}% de desconto
          </span>
          {post.promoValidUntil && (
            <span className="text-zinc-500 text-xs ml-auto">
              válido até {new Date(post.promoValidUntil).toLocaleDateString("pt-BR")}
            </span>
          )}
        </div>
      )}

      {/* Ações */}
      <div className="flex items-center gap-4 px-4 pt-3">
        <button
          onClick={() => toggleLike({ postId: post._id, userId: currentUserId })}
          className="flex items-center gap-1.5 text-zinc-400 hover:text-red-400 transition-colors"
        >
          <Heart size={20} />
          <span className="text-sm">{post.likesCount}</span>
        </button>
        <button
          onClick={() => setShowComments((v) => !v)}
          className="flex items-center gap-1.5 text-zinc-400 hover:text-amber-400 transition-colors"
        >
          <MessageCircle size={20} />
          <span className="text-sm">{post.commentsCount}</span>
        </button>
      </div>

      {/* Legenda */}
      {post.caption && (
        <p className="text-zinc-300 text-sm px-4 pt-2">
          <span className="text-white font-medium">{post.professionalName}</span>{" "}
          {post.caption}
        </p>
      )}

      {/* Comentários */}
      {showComments && (
        <div className="px-4 py-3 border-t border-zinc-800 mt-3 space-y-2">
          {comments?.map((c) => (
            <p key={c._id} className="text-sm">
              <span className="text-white font-medium">{c.userName}</span>{" "}
              <span className="text-zinc-400">{c.text}</span>
            </p>
          ))}
          <div className="flex gap-2 pt-2">
            <input
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Adicione um comentário..."
              className="flex-1 bg-zinc-800 text-white text-sm rounded-lg px-3 py-2 outline-none focus:ring-1 focus:ring-amber-500"
            />
            <button
              onClick={async () => {
                if (!commentText.trim()) return;
                await addComment({
                  postId: post._id,
                  userId: currentUserId,
                  userName: "Você",
                  text: commentText.trim(),
                });
                setCommentText("");
              }}
              className="text-amber-400 text-sm font-medium px-3"
            >
              Enviar
            </button>
          </div>
        </div>
      )}
      <div className="pb-4" />
    </div>
  );
}

// ---------------------------------------------------------------------
// Feed completo com paginação infinita
// ---------------------------------------------------------------------
export default function ProfessionalFeed({ currentUserId }: { currentUserId: Id<"users"> }) {
  const { results, status, loadMore } = usePaginatedQuery(
    api.professionalFeed.listFeed,
    {},
    { initialNumItems: 6 }
  );

  return (
    <div className="max-w-xl mx-auto">
      <StoriesBar />

      <div className="space-y-4">
        {results.map((post) => (
          <PostCard key={post._id} post={post} currentUserId={currentUserId} />
        ))}
      </div>

      {status === "CanLoadMore" && (
        <button
          onClick={() => loadMore(6)}
          className="w-full mt-4 py-3 rounded-lg border border-zinc-800 text-zinc-400 hover:text-amber-400 hover:border-amber-500/50 transition-colors text-sm"
        >
          Carregar mais
        </button>
      )}
      {status === "LoadingMore" && (
        <p className="text-center text-zinc-500 text-sm mt-4">Carregando...</p>
      )}
      {results.length === 0 && status !== "LoadingFirstPage" && (
        <p className="text-center text-zinc-500 text-sm mt-8">
          Ainda não há publicações no feed.
        </p>
      )}
    </div>
  );
}

"use client";

// ============================================================================
// components/Marketplace.tsx — ATAMURA SERVIÇOS Ω
// ============================================================================

import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { TODAS_PROFISSOES } from "@/lib/categoriasProfissoes";
import {
  Hammer,
  ShieldCheck,
  Package,
  Cog,
  KeyRound,
  Puzzle,
  Wrench,
  Tag,
} from "lucide-react";

const DEPARTMENTS = [
  { key: "ferramentas", label: "Ferramentas", icon: Hammer },
  { key: "epis", label: "EPIs", icon: ShieldCheck },
  { key: "materiais", label: "Materiais", icon: Package },
  { key: "maquinas", label: "Máquinas", icon: Cog },
  { key: "aluguel", label: "Aluguel", icon: KeyRound },
  { key: "pecas", label: "Peças", icon: Puzzle },
  { key: "equipamentos", label: "Equipamentos", icon: Wrench },
] as const;

function formatBRL(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function Marketplace({ buyerId }: { buyerId: Id<"users"> }) {
  const [selected, setSelected] = useState<(typeof DEPARTMENTS)[number]["key"] | null>(null);
  const [profession, setProfession] = useState<string | null>(null);
  const counts = useQuery(api.marketplace.countByDepartment) ?? {};
  const products = useQuery(
    api.marketplace.listByDepartment,
    selected ? { department: selected } : "skip"
  );
  const productsByProfession = useQuery(
    api.marketplace.listByProfession,
    profession ? { relatedProfession: profession } : "skip"
  );
  const promotions = useQuery(api.marketplace.listPromotions);
  const createOrder = useMutation(api.marketplace.createOrder);

  return (
    <div>
      {/* Filtro rápido por profissão (ex: "Produtos para Pintor") */}
      <div className="mb-4">
        <p className="text-zinc-500 text-xs mb-2">Filtrar por profissão</p>
        <div className="flex flex-wrap gap-1.5">
          {TODAS_PROFISSOES.slice(0, 14).map((prof) => (
            <button
              key={prof}
              onClick={() => {
                setProfession(profession === prof ? null : prof);
                setSelected(null);
              }}
              className={`text-[11px] px-2.5 py-1 rounded-md transition-colors ${
                profession === prof ? "bg-amber-500 text-black font-medium" : "bg-zinc-800 text-zinc-300"
              }`}
            >
              {prof}
            </button>
          ))}
        </div>
      </div>

      {profession && (
        <div className="mb-6">
          <p className="text-white text-sm font-medium mb-3">Produtos para {profession}</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {productsByProfession?.map((p) => (
              <ProductCard
                key={p._id}
                product={p}
                buyerId={buyerId}
                onBuy={(qty) => createOrder({ productId: p._id, buyerId, quantity: qty })}
              />
            ))}
            {productsByProfession?.length === 0 && (
              <p className="text-zinc-500 text-sm col-span-full">
                Nenhum produto vinculado a essa profissão ainda.
              </p>
            )}
          </div>
        </div>
      )}
      {/* Grade de departamentos */}
      <div className="grid grid-cols-4 sm:grid-cols-7 gap-3 mb-6">
        {DEPARTMENTS.map((dept) => {
          const Icon = dept.icon;
          const active = selected === dept.key;
          return (
            <button
              key={dept.key}
              onClick={() => setSelected(active ? null : dept.key)}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-colors ${
                active
                  ? "border-amber-500 bg-amber-500/10"
                  : "border-zinc-800 bg-zinc-900/60 hover:border-zinc-700"
              }`}
            >
              <Icon size={22} className={active ? "text-amber-400" : "text-zinc-400"} />
              <span className={`text-xs ${active ? "text-amber-400" : "text-zinc-400"}`}>
                {dept.label}
              </span>
              <span className="text-[10px] text-zinc-600">{counts[dept.key] ?? 0}</span>
            </button>
          );
        })}
      </div>

      {/* Promoções (quando nenhum departamento selecionado) */}
      {!selected && promotions && promotions.length > 0 && (
        <div className="mb-6">
          <p className="text-white text-sm font-medium mb-3">Promoções</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {promotions.map((p) => (
              <ProductCard
                key={p._id}
                product={p}
                buyerId={buyerId}
                onBuy={(qty) => createOrder({ productId: p._id, buyerId, quantity: qty })}
              />
            ))}
          </div>
        </div>
      )}

      {/* Produtos do departamento selecionado */}
      {selected && (
        <div>
          <p className="text-white text-sm font-medium mb-3">
            {DEPARTMENTS.find((d) => d.key === selected)?.label}
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {products?.map((p) => (
              <ProductCard
                key={p._id}
                product={p}
                buyerId={buyerId}
                onBuy={(qty) => createOrder({ productId: p._id, buyerId, quantity: qty })}
              />
            ))}
            {products?.length === 0 && (
              <p className="text-zinc-500 text-sm col-span-full">
                Nenhum produto neste departamento ainda.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function ProductCard({
  product,
  onBuy,
}: {
  product: any;
  buyerId: Id<"users">;
  onBuy: (qty: number) => void;
}) {
  const finalPrice = product.isPromo
    ? Math.round(product.priceCents * (1 - (product.promoDiscountPercent ?? 0) / 100))
    : product.priceCents;

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden">
      <div className="aspect-square bg-zinc-800 flex items-center justify-center">
        {product.imageUrls?.[0] ? (
          <img src={product.imageUrls[0]} alt={product.name} className="w-full h-full object-cover" />
        ) : (
          <Package size={28} className="text-zinc-600" />
        )}
      </div>
      <div className="p-3">
        <p className="text-white text-sm font-medium line-clamp-1">{product.name}</p>
        <div className="flex items-center gap-2 mt-1">
          {product.isPromo && (
            <span className="text-zinc-500 text-xs line-through">
              {formatBRL(product.priceCents)}
            </span>
          )}
          <span className="text-amber-400 text-sm font-semibold">{formatBRL(finalPrice)}</span>
        </div>
        {product.isRental && (
          <p className="text-zinc-500 text-xs mt-0.5">
            Aluguel: {formatBRL(product.rentalPricePerDayCents ?? 0)}/dia
          </p>
        )}
        {product.isPromo && (
          <span className="inline-flex items-center gap-1 text-[10px] text-amber-400 mt-1">
            <Tag size={10} /> {product.promoDiscountPercent}% off
          </span>
        )}
        <button
          onClick={() => onBuy(1)}
          disabled={product.stock <= 0}
          className="mt-2 w-full text-xs font-medium py-1.5 rounded-lg bg-amber-500 text-black disabled:bg-zinc-800 disabled:text-zinc-600"
        >
          {product.stock > 0 ? "Comprar" : "Sem estoque"}
        </button>
      </div>
    </div>
  );
}

"use client";

// ============================================================================
// components/SolicitarServico.tsx — Apiaí Serviços
// Formulário do cliente pra pedir um serviço pela primeira vez.
// ============================================================================

import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { DEPARTAMENTOS } from "@/lib/categoriasProfissoes";
import { MapPin, DollarSign, Image as ImageIcon, Loader2 } from "lucide-react";

export default function SolicitarServico({
  clientId,
  initialCategory,
  initialSubcategory,
  onCreated,
}: {
  clientId: Id<"users">;
  initialCategory?: string;
  initialSubcategory?: string;
  onCreated?: (orderId: string) => void;
}) {
  const [category, setCategory] = useState(initialCategory ?? "");
  const [subcategory, setSubcategory] = useState(initialSubcategory ?? "");
  const [description, setDescription] = useState("");
  const [address, setAddress] = useState("");
  const [budgetMin, setBudgetMin] = useState("");
  const [budgetMax, setBudgetMax] = useState("");
  const [photos, setPhotos] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);

  const generateUploadUrl = useMutation(api.solicitarServico.generateUploadUrl);
  const createOrder = useMutation(api.solicitarServico.createServiceOrder);

  const departamento = DEPARTAMENTOS.find((d) => d.key === category);

  async function handleSubmit() {
    if (!category || !subcategory || !description.trim()) return;
    setLoading(true);
    try {
      const photoStorageIds = await Promise.all(
        photos.map(async (file) => {
          const uploadUrl = await generateUploadUrl();
          const result = await fetch(uploadUrl, {
            method: "POST",
            headers: { "Content-Type": file.type },
            body: file,
          });
          const { storageId } = await result.json();
          return storageId;
        })
      );

      const orderId = await createOrder({
        clientId,
        category,
        subcategory,
        description: description.trim(),
        addressText: address.trim() || undefined,
        budgetMinCents: budgetMin ? Math.round(parseFloat(budgetMin) * 100) : undefined,
        budgetMaxCents: budgetMax ? Math.round(parseFloat(budgetMax) * 100) : undefined,
        photoStorageIds,
      });

      onCreated?.(orderId as unknown as string);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 max-w-lg mx-auto">
      <p className="text-white text-lg font-semibold mb-1">Solicitar serviço</p>
      <p className="text-zinc-500 text-sm mb-5">Descreva o que você precisa e receba orçamentos</p>

      <p className="text-zinc-400 text-xs mb-2">Departamento</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
        {DEPARTAMENTOS.map((dept) => (
          <button
            key={dept.key}
            onClick={() => {
              setCategory(dept.key);
              setSubcategory("");
            }}
            className={`text-xs text-left px-3 py-2 rounded-lg border transition-colors ${
              category === dept.key
                ? "border-amber-500 bg-amber-500/10 text-amber-400"
                : "border-zinc-800 text-zinc-300"
            }`}
          >
            {dept.label}
          </button>
        ))}
      </div>

      {departamento && (
        <>
          <p className="text-zinc-400 text-xs mb-2">Profissão</p>
          <div className="flex flex-wrap gap-2 mb-4">
            {departamento.profissoes.map((prof) => (
              <button
                key={prof}
                onClick={() => setSubcategory(prof)}
                className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${
                  subcategory === prof
                    ? "border-amber-500 bg-amber-500 text-black font-medium"
                    : "border-zinc-800 text-zinc-300"
                }`}
              >
                {prof}
              </button>
            ))}
          </div>
        </>
      )}

      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Descreva o serviço que você precisa..."
        rows={3}
        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none mb-3 resize-none"
      />

      <div className="relative mb-3">
        <MapPin size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Endereço ou bairro"
          className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
        />
      </div>

      <div className="flex items-center gap-2 mb-3">
        <div className="relative flex-1">
          <DollarSign size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            value={budgetMin}
            onChange={(e) => setBudgetMin(e.target.value)}
            placeholder="Orçamento mín."
            className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
          />
        </div>
        <div className="relative flex-1">
          <DollarSign size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            value={budgetMax}
            onChange={(e) => setBudgetMax(e.target.value)}
            placeholder="Orçamento máx."
            className="w-full bg-zinc-800 border border-zinc-700 rounded-lg pl-9 pr-3 py-2 text-sm text-white placeholder:text-zinc-500 outline-none"
          />
        </div>
      </div>

      <label className="flex items-center gap-2 text-zinc-400 text-xs mb-4 cursor-pointer">
        <ImageIcon size={15} />
        {photos.length > 0 ? `${photos.length} foto(s) selecionada(s)` : "Adicionar fotos (opcional)"}
        <input
          type="file"
          accept="image/*"
          multiple
          onChange={(e) => setPhotos(Array.from(e.target.files ?? []))}
          className="hidden"
        />
      </label>

      <button
        onClick={handleSubmit}
        disabled={!category || !subcategory || !description.trim() || loading}
        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-amber-500 text-black text-sm font-medium disabled:bg-zinc-800 disabled:text-zinc-600"
      >
        {loading && <Loader2 size={15} className="animate-spin" />}
        {loading ? "Enviando..." : "Solicitar serviço"}
      </button>
    </div>
  );
}

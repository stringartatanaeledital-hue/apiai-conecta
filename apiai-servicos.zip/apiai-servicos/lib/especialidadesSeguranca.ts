// ============================================================================
// lib/especialidadesSeguranca.ts — ATAMURA SERVIÇOS Ω
// Especialidades usadas quando um profissional se cadastra na categoria
// "Segurança do trabalho". Use essa lista em selects de cadastro de perfil
// (professionalPortfolios.specialties) e para filtrar cursos NR.
// ============================================================================

export const ESPECIALIDADES_SEGURANCA_TRABALHO = [
  "Elaboração de PPRA/PGR",
  "Análise de risco (APR)",
  "Emissão de permissão de trabalho",
  "Bloqueio e etiquetagem (LOTO)",
  "Trabalho em espaço confinado",
  "Trabalho em altura",
  "Inspeção e gestão de EPI",
  "Auditoria de segurança do trabalho",
  "Treinamento de brigada de incêndio",
  "Investigação de acidentes",
  "Elaboração de laudos técnicos (LTCAT, PCMSO)",
  "Segurança em espaços confinados industriais",
] as const;

// Sugestão de filtro para a tela de busca / marketplace de profissionais:
// professionals.category === "seguranca_trabalho"
// com professionalPortfolios.specialties contendo uma ou mais destas.

"use client";

// ============================================================================
// lib/SessionContext.tsx — Apiaí Serviços
// Contexto simples de sessão: guarda o usuário logado e persiste no
// localStorage do navegador (isso é código real do seu app Next.js, não
// um artifact — localStorage funciona normalmente aqui).
// ============================================================================

import { createContext, useContext, useEffect, useState, ReactNode } from "react";

type SessionUser = {
  userId: string;
  name: string;
  email: string;
  role: "cliente" | "profissional" | "empresa" | "admin";
};

type SessionContextValue = {
  user: SessionUser | null;
  login: (user: SessionUser) => void;
  logout: () => void;
  isLoading: boolean;
};

const SessionContext = createContext<SessionContextValue | null>(null);

const STORAGE_KEY = "apiai_servicos_session";

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
    setIsLoading(false);
  }, []);

  function login(newUser: SessionUser) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
    setUser(newUser);
  }

  function logout() {
    localStorage.removeItem(STORAGE_KEY);
    setUser(null);
  }

  return (
    <SessionContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </SessionContext.Provider>
  );
}

export function useSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error("useSession precisa estar dentro de <SessionProvider>");
  return ctx;
}

// ----------------------------------------------------------------------
// USO — envolva sua aplicação uma vez, no layout principal:
//
// // app/layout.tsx
// import { SessionProvider } from "@/lib/SessionContext";
// export default function RootLayout({ children }) {
//   return <html><body><SessionProvider>{children}</SessionProvider></body></html>;
// }
//
// Depois, em qualquer componente:
// const { user, login, logout } = useSession();
// ----------------------------------------------------------------------

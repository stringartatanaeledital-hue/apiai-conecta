"use client";

// ============================================================================
// lib/ConvexClientProvider.tsx — Apiaí Serviços
// Conecta o app ao backend Convex. A URL vem de NEXT_PUBLIC_CONVEX_URL
// (gerada automaticamente quando você roda `npx convex dev` ou
// `npx convex deploy` — veja o .env.local.example).
// ============================================================================

import { ConvexProvider, ConvexReactClient } from "convex/react";
import { ReactNode } from "react";

const convex = new ConvexReactClient(process.env.NEXT_PUBLIC_CONVEX_URL as string);

export function ConvexClientProvider({ children }: { children: ReactNode }) {
  return <ConvexProvider client={convex}>{children}</ConvexProvider>;
}
